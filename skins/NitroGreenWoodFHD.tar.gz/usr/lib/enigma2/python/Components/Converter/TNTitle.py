# -*- coding: utf-8 -*-
#

from Components.Converter.Converter import Converter
from Components.Element import cached
from Components.config import config

class TNTitle(Converter, object):
	def __init__(self, type):
		Converter.__init__(self, type)

	@cached
	def getText(self):
		title = self.source.text
		t = " (%s) " % config.servicelist.lastmode.value.upper()
		pos = title.find(t)
		if pos != -1:
			title = title[pos+len(t):]
		return title

	text = property(getText)