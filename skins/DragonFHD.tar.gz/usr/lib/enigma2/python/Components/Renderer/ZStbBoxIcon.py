from __future__ import absolute_import 
from Components.Renderer.Renderer import Renderer 
from enigma import ePixmap
from Tools.Directories import SCOPE_CURRENT_SKIN, resolveFilename
import os

try:
    from boxbranding import getBoxType
except:
    from enigma import getBoxType

def getModelString():
        model = getBoxType()
        return model

class ZStbBoxIcon(Renderer):
   
    def __init__(self):
        Renderer.__init__(self)
        self.iconPath = resolveFilename(SCOPE_CURRENT_SKIN, 'icons')
        self.BoxIcon = 'unknown.png'
        self.BoxIcon = getModelString() + '.png'        
        self.currIcon = os.path.join(self.iconPath, self.BoxIcon)

    def applySkin(self, desktop, parent):
        attribs = self.skinAttributes[:]
        for attrib, value in self.skinAttributes:
            if attrib == 'iconspath':
                if value[:1] == '/':
                    self.iconPath = value
                else:
                    self.iconPath = resolveFilename(SCOPE_CURRENT_SKIN, value)
                attribs.remove((attrib, value))
                
                self.currIcon = os.path.join(self.iconPath, self.BoxIcon)
                try:
                    self.changed((self.CHANGED_DEFAULT,))
                except Exception:
                    pass

        self.skinAttributes = attribs
        
        return Renderer.applySkin(self, desktop, parent)

    GUI_WIDGET = ePixmap

    def postWidgetCreate(self, instance):
        self.changed((self.CHANGED_DEFAULT,))

    def changed(self, what):
        if what[0] != self.CHANGED_CLEAR:
            if self.source:
                if self.instance:
                    self.instance.setPixmapFromFile(self.currIcon)
                    self.instance.show()
