#!/usr/bin/python
# -*- coding: utf-8 -*-
#Coded By KIMO and Bahaa
#modify it if you keep the licens
###########################################
from __future__ import absolute_import
from .__init__ import _
from os.path import join, isdir, exists, isfile, split
import sys
from enigma import eTimer, getDesktop,ePicLoad, eListboxPythonMultiContent, gFont
from Components.ActionMap import ActionMap
from Components.config import *
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.AVSwitch import AVSwitch
from Components.MultiContent import MultiContentEntryText
from Screens.ChoiceBox import ChoiceBox
from Screens.InputBox import InputBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
try:
    from Screens.SkinSelection import SkinSelection
except:
    from Screens.SkinSelector import SkinSelector as SkinSelection
from Tools.LoadPixmap import LoadPixmap
from Tools import Notifications
from Tools.Notifications import AddPopup
from Tools.Directories import *
from Tools.Directories import fileExists, pathExists, createDir, resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE, SCOPE_CONFIG, SCOPE_SKIN, SCOPE_CURRENT_SKIN
import re, os, shutil
from os import listdir, remove, rename, system, path, symlink, chdir, makedirs, mkdir
from os import path as os_path, remove as os_remove, listdir as os_listdir
from os import path, remove
from Plugins.Extensions.TeamNitro.Console import Console
from Plugins.Extensions.TeamNitro.WeatherMSN import WeatherMSN
from Plugins.Extensions.TeamNitro.changelog import TeamNitro_Changelog
from Plugins.Extensions.TeamNitro.about import TeamNitro_About
from Plugins.Extensions.TeamNitro.TNFonts import TNFonts, sessionstart
from Plugins.Extensions.TeamNitro.SkinDownload import SkinDownload
from Plugins.Extensions.TeamNitro.AL_AYAM_FHD import AL_AYAM_FHD
from Plugins.Extensions.TeamNitro.DesertFHD import DesertFHD
from Plugins.Extensions.TeamNitro.NitroAdvanceFHD import NitroAdvanceFHD
from Plugins.Extensions.TeamNitro.RED_DRAGON_FHD import RED_DRAGON_FHD
from Plugins.Extensions.TeamNitro.PiconDownload import PiconDownload
from Plugins.Plugin import PluginDescriptor
from smtplib import SMTP
from six.moves.urllib.request import urlretrieve
from .compat import compat_urlopen, compat_Request, compat_URLError, PY3
from .tools import getmDevices
from Components.config import config, ConfigSubsection, ConfigEnableDisable, ConfigSelection, ConfigYesNo, getConfigListEntry, configfile
from enigma import getDesktop, addFont
from .compat import PY3

cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
reswidth = getDesktop(0).size().width()
config.plugins.TeamNitro = ConfigSubsection()
config.plugins.TeamNitro.update = ConfigYesNo(default=True)
config.plugins.TeamNitro.skin_selection = ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK")) ])

config.plugins.TeamNitro.skin_TNCleaner= ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK")) ])

config.plugins.TeamNitro.MSNWeather = ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK"))
                                ])
config.plugins.TeamNitro.skinDownload = ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK"))
                                ])
config.plugins.TeamNitro.piconDownload= ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK"))
                                ])
config.plugins.TeamNitro.TNChangelog = ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK"))
                                ])
config.plugins.TeamNitro.TNAbout = ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK"))
                                ])
config.plugins.TeamNitro.proMode = ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK"))
                                ])
config.plugins.TeamNitro.DesertFHD = ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK")) ])
config.plugins.TeamNitro.RED_DRAGON_FHD = ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK"))
                                ])
config.plugins.TeamNitro.NitroAdvanceFHD= ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK"))
                                ])
config.plugins.TeamNitro.AL_AYAM_FHD = ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK"))
                                ])


config.plugins.TeamNitro.fonts1 = ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK"))
                                ])
### picon color##
COLOREPLUGIN=resolveFilename(SCOPE_PLUGINS, "Extensions/TeamNitro/PICONS/")

config.plugins.TeamNitro.piconpath = ConfigSelection(default = "PLUGIN", choices = [
    ("PLUGIN", _("PLUGIN")),
    ("MEDIA", _("MEDIA"))
    ])

def getmDevices():
        myusb = myusb1 = myhdd = myhdd2 = mysdcard = mysd = myuniverse = myba = mydata =''
        mdevices = []
        myusb=None
        myusb1=None
        myhdd=None
        myhdd2=None
        mysdcard=None
        mysd=None
        myuniverse=None
        myba=None
        mydata=None
        if fileExists('/proc/mounts'):
            f = open('/proc/mounts', 'r')
            for line in f.readlines():
                if line.find('/media/usb') != -1:
                    myusb = '/media/usb'
                elif line.find('/media/usb1') != -1:
                    myusb1 = '/media/usb1'
                elif line.find('/media/hdd') != -1:
                    myhdd = '/media/hdd'
                elif line.find('/media/hdd2') != -1:
                    myhdd2 = '/media/hdd2'
                elif line.find('/media/sdcard') != -1:
                    mysdcard = '/media/sdcard'
                elif line.find('/media/sd') != -1:
                    mysd = '/media/sd'
                elif line.find('/universe') != -1:
                    myuniverse = '/universe'
                elif line.find('/media/ba') != -1:
                    myba = '/media/ba'
                elif line.find('/data') != -1:
                    mydata = '/data'
            f.close()
        if myusb:
            mdevices.append((myusb, myusb))
        if myusb1:
            mdevices.append((myusb1, myusb1))
        if myhdd:
            mdevices.append((myhdd, myhdd))
        if myhdd2:
            mdevices.append((myhdd2, myhdd2))
        if mysdcard:
            mdevices.append((mysdcard, mysdcard))
        if mysd:
            mdevices.append((mysd, mysd))
        if myuniverse:
            mdevices.append((myuniverse, myuniverse))
        if myba:
            mdevices.append((myba, myba))
        if mydata:
            mdevices.append((mydata, mydata))
        return mdevices
mounted_devices = getmDevices()
config.plugins.TeamNitro.device_path = ConfigSelection(choices = mounted_devices)
if config.plugins.TeamNitro.piconpath.value == "MEDIA":
        PATHPICON = config.plugins.TeamNitro.device_path.value
elif config.plugins.TeamNitro.piconpath.value == "PLUGIN":
        PATHPICON = '/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro'


REDC = '\033[31m'
ENDC = '\033[m'
def cprint(text):
    print(REDC + text + ENDC)

def removeunicode(data):
    try:
        try:
                data = data.encode('utf', 'ignore')
        except:
                pass
        data = data.decode('unicode_escape').encode('ascii', 'replace').replace('?', '').strip()
    except:
        pass
    return data

def trace_error():
    import sys
    import traceback
    try:
        traceback.print_exc(file=sys.stdout)
        traceback.print_exc(file=open('/tmp/TeamNitro.log', 'a'))
    except:
        pass

def logdata(label_name = '', data = None):
    try:
        data=str(data)
        fp = open('/tmp/TeamNitro.log', 'a')
        fp.write( str(label_name) + ': ' + data+"\n")
        fp.close()
    except:
        trace_error()
        pass

def dellog(label_name = "", data = None):
        try:
                if os_path.exists("/tmp/TeamNitro.log"):
                        os_remove("/tmp/TeamNitro.log")
        except:
                pass

def Plugins(**kwargs):
    return [
         PluginDescriptor(
              name=_("TeamNitro Control Center"), 
              description=_("Access Multiple TeamNitro Options"), 
              where = [PluginDescriptor.WHERE_SESSIONSTART],
              icon="plugin.png", fnc=sessionstart
        ),
         PluginDescriptor(
              name=_("TeamNitro Control Center"), 
              description=_("Access Multiple TeamNitro Options"), 
              where = [PluginDescriptor.WHERE_PLUGINMENU],
              icon="plugin.png", fnc=main
        )
        ]

def main(session, **kwargs):
    try:
        # Path to the plugin directory
        plugin_path = "/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro"

        # Check for .pyc files in the plugin directory
        pyc_files = [f for f in os.listdir(plugin_path) if f.endswith(".pyc")]

        if pyc_files:
            # Remove all .py files if .pyc files exist
            py_files = [f for f in os.listdir(plugin_path) if f.endswith(".py")]
            for py_file in py_files:
                file_path = os.path.join(plugin_path, py_file)
                try:
                    os.remove(file_path)
                    #print(f"Deleted: {file_path}")
                    pass
                except Exception as e:
                    #print(f"Failed to delete {file_path}: {e}")
                    pass

        # Read the settings file
        with open("/etc/enigma2/settings", "r") as f:
            settings = f.readlines()

        # Find the current skin setting
        skin_setting = None
        for line in settings:
            if line.startswith("config.skin.primary_skin="):
                skin_setting = line.split("=")[1].strip()
                break

        # List of allowed skins
        allowed_skins = [
            "DesertFHD/skin.xml",
            "NitroAdvanceFHD/skin.xml",
            "RED_DRAGON_FHD/skin.xml",
            "AL_AYAM_FHD/skin.xml"
        ]

        # Check if the current skin is in the allowed list
        if skin_setting and skin_setting in allowed_skins:
            session.open(TeamNitro)  # Open the TeamNitro screen
        else:
            # Show error message
            session.open(MessageBox, _("This plugin requires a Team Nitro skin!"), type=MessageBox.TYPE_ERROR)

    except Exception as e:
        # Handle any unexpected errors
        session.open(MessageBox, _("An error occurred: ") + str(e), type=MessageBox.TYPE_ERROR)


def isInteger(s):
    try:
        int(s)
        return True
    except ValueError:
        return False

SKIN_VIEW = """
<screen name="MainSettingsView" position="0,0" size="1920,1080" title="Main Menu" flags="wfNoBorder" backgroundColor="transparent">
    <widget source="session.VideoPicture" render="Pig" position="1186,609" size="672,389" zPosition="3" backgroundColor="transparent" />
    <ePixmap position="0,0" size="1920,1086" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/mn.png" alphatest="off" transparent="1" />
    <ePixmap position="263,106" size="800,80" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/bar.png" alphatest="off" transparent="1" />
    <widget source="Title" render="Label" position="288,111" size="752,68" zPosition="1" halign="center" font="Regular;46" backgroundColor="bglist" transparent="1" />
    <widget name="config" position="247,199" size="830,761" font="Regular;34" itemHeight="45" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/barr.png" enableWrapAround="1" transparent="1" />
    <widget name="Picture" position="1184,130" scale="1" size="671,436" alphatest="blend" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/red48x48.png" position="275,970" size="48,48" alphatest="blend" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/green48x48.png" position="772,970" size="48,48" alphatest="blend" />
    <widget name="key_red" position="332,970" size="300,48" zPosition="1" font="Regular; 35" halign="left" valign="center" backgroundColor="#000000" transparent="1" foregroundColor="#FA0909" />
    <widget name="key_green" position="830,970" size="230,48" zPosition="1" font="Regular; 35" halign="left" valign="center" backgroundColor="#000000" transparent="1" foregroundColor="#05A115" />
</screen>
    """

class TeamNitro(Screen, ConfigListScreen):

    def __init__(self, session, args = 0):
        self.session = session
        self.changed_screens = False
        Screen.__init__(self, session)
        self.skin = SKIN_VIEW
        self.list = []
        ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
        self.configChanged = False
        self["key_red"] = Label(_("Exit"))
        self["key_green"] = Label(_("Save Changes"))
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "EPGSelectActions"],
                {
                        "red": self.cancel,
                        "cancel": self.cancel,
                        "ok": self.keyOk,
                        "right": self.keyRight,
                        "left": self.keyLeft,
                        "green": self.keyGreen,
                }, -2)

        self["Picture"] = Pixmap()
        self.timer = eTimer()
        if config.plugins.TeamNitro.update.value:
            self.checkupdates()
        self.createConfigList()

    def createConfigList(self):
        self.set_proMode= getConfigListEntry(_("Pro. Additional Skins"), config.plugins.TeamNitro.proMode)
        self.set_skin_selection= getConfigListEntry(_("Change Skin"), config.plugins.TeamNitro.skin_selection)
        self.set_TNCleaner = getConfigListEntry(_("Delete Skin"), config.plugins.TeamNitro.skin_TNCleaner)
        self.set_MSNWeather= getConfigListEntry(_("WeatherMSN Settings"), config.plugins.TeamNitro.MSNWeather)
        self.set_skinDownload = getConfigListEntry(_("Download TeamNitro Skins "), config.plugins.TeamNitro.skinDownload)
        
        self.update = getConfigListEntry(_("Enable/Disable online update Info"), config.plugins.TeamNitro.update)
        self.set_TNChangelog= getConfigListEntry(_("Changelog"), config.plugins.TeamNitro.TNChangelog)
        self.set_TNAbout= getConfigListEntry(_("About TeamNitro"), config.plugins.TeamNitro.TNAbout)
        self.LackOfFile = ''
        self.list = []
        if config.skin.primary_skin.value == "DesertFHD/skin.xml":
             self.list.append(self.set_proMode)
        elif config.skin.primary_skin.value == "NitroAdvanceFHD/skin.xml":
             self.list.append(self.set_proMode)
        elif config.skin.primary_skin.value == "RED_DRAGON_FHD/skin.xml":
             self.list.append(self.set_proMode)
        # elif config.skin.primary_skin.value == "KIII_PRO/skin.xml":
        #      self.list.append(self.set_proMode)
        elif config.skin.primary_skin.value == "AL_AYAM_FHD/skin.xml":
             self.list.append(self.set_proMode)
        else:
             pass
        self.list.append(self.set_skin_selection)
        self.list.append(self.set_TNCleaner)
        self.list.append(self.set_MSNWeather)
        self.list.append(self.set_skinDownload)
        
        self.list.append(self.update)
        self.list.append(self.set_TNChangelog)
        self.list.append(self.set_TNAbout)
        self["config"].list = self.list
        self["config"].l.setList(self.list)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.createConfigList()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.createConfigList()

    def keyGreen(self):
        for x in self['config'].list:
            x[1].save()
            configfile.save()
            self.restartGUI()

    def showSkinChoiceBox(self):
        self.guiRoot = resolveFilename(SCOPE_SKIN)
        choices = []
        for directory in [x for x in os.listdir(self.guiRoot) if os.path.isdir(os.path.join(self.guiRoot, x))]:
            skin_xml_path = os.path.join(self.guiRoot, directory, "skin.xml")
            if os.path.exists(skin_xml_path):
                label = _("< Default >") if directory == "skin_default" else directory
                choices.append((os.path.join(self.guiRoot, directory), label))
        self.session.openWithCallback(self.skinChoiceCallback, ChoiceBox, title=_("Select skin to delete"), list=choices)

    def skinChoiceCallback(self, choice):
        if choice:
            skinDirPath, skinLabel = choice
            print("[TeamNitro] Trying to delete skin: %s at %s" % (skinLabel, skinDirPath))
            if os.path.exists(skinDirPath):
                try:
                    shutil.rmtree(skinDirPath)
                    self.session.open(MessageBox, _("Skin '%s' has been deleted.") % skinLabel, MessageBox.TYPE_INFO)
                    print("[TeamNitro] Skin '%s' has been deleted." % skinLabel)
                except Exception as e:
                    self.session.open(MessageBox, _("Failed to delete skin '%s': %s") % (skinLabel, str(e)), MessageBox.TYPE_ERROR)
    def restartGUI(self):
        self.createConfigList()
        restartbox = self.session.openWithCallback(self.restartGUIcb, MessageBox, _("All Changes are Saved \n\n Restart necessary,\n PRESS OK to restart GUI now?"), MessageBox.TYPE_INFO)

    def restartGUIcb(self, answer):
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()

    def cancel(self):

        if self["config"].isChanged():
            self.session.openWithCallback(self.cancelConfirm, MessageBox, _("DO you want to close without saving the settings?\n\n\n Press The Green Button for Saving the Settings"), MessageBox.TYPE_YESNO, default = False)
        else:
            for x in self["config"].list:
                x[1].cancel()
            if self.changed_screens:
                self.restartGUI()
            else:
                self.close()



    def keyOk(self):
        sel = self["config"].getCurrent()
        if sel is not None:
            if sel == self.set_proMode:
                self.session.open(TeamNitro_Config)
            elif sel == self.set_MSNWeather:
                self.session.open(WeatherMSN)
            elif sel == self.set_skinDownload:
                self.session.open(SkinDownload)
            elif sel == self.set_TNChangelog:
                self.session.open(TeamNitro_Changelog)
            elif sel == self.set_TNAbout:
                self.session.open(TeamNitro_About)
            elif sel == self.set_skin_selection:
                self.session.openWithCallback(self.skinChanged, SkinSelection)
            elif sel == self.set_TNCleaner:
                self.showSkinChoiceBox()

    def skinChanged(self, ret = None):
        global cur_skin
        cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
        if cur_skin == "skin.xml":
            self.restartGUI()
        else:
            return

    def checkupdates(self):
        url1=[]
        url1.append('https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/InstallerN.sh')
        url1.append('https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerD.sh')
        url1.append('https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerB.sh')
        url1.append('https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerDs.sh')
        url1.append('https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerAL.sh')
        url1.append('https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/plugin.sh')
        for url in url1:
            self.callUrl(url, self.checkVer)

    def checkVer(self, data):
        import os
        currversion =[]
        version_file = '/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/TN_Skins_version'
        if os.path.exists(version_file):
                try:
                    fp = open(version_file, 'r').readlines()
                    for line in fp:
                        if 'versionNitro' in line:
                            currversion.append(line.split('=')[1].strip())
                        elif 'versionDragon' in line:
                            currversion.append(line.split('=')[1].strip())
                        elif 'versionDesert' in line:
                            currversion.append(line.split('=')[1].strip())
                        elif 'versionPlugin' in line:
                            currversion.append(line.split('=')[1].strip())
                        elif 'versionAL_AYAM_FHD' in line:
                            currversion.append(line.split('=')[1].strip())
                except:
                    pass

        if PY3:
            data = data.decode("utf-8")
        else:
            data = data.encode("utf-8")
        if data:
            lines = data.split("\n")
            for line in lines:
                if line.startswith("version"):
                   self.new_version = line.split("=")[1]
                if line.startswith("description"):
                   self.new_description = line.split("=")[1]
                   break
        new_descriptiona=self.new_description
        if new_descriptiona.find("Skin_Nitro")==1:
           Ver=currversion[0]
        elif new_descriptiona.find("Skin_Dragon")==1:
             Ver=currversion[1]
        elif new_descriptiona.find("Skin_Desert")==1:
             Ver=currversion[3]
        elif new_descriptiona.find("ControlCenter")==1:
             Ver=currversion[4]
        elif new_descriptiona.find("AL_AYAM_FHD")==1:
             Ver=currversion[4]

        if float(Ver) == float(self.new_version) or float(Ver) > float(self.new_version):
            pass
        else:
            new_descriptiona=self.new_description
            self.session.open( MessageBox, _(' \n ========= An Update is available for========= \n\n%s\n\n  *****   Updates are in the plugin downloads     ***** \n\nPress (-OK or Exit-) to remove or view other INFO  ' % (new_descriptiona)), MessageBox.TYPE_INFO)

    def myCallback(self, result=None):
        return

    def callUrl(self, url, callback):
        try:
            from twisted.web.client import getPage
            getPage(str.encode(url), headers={b'Content-Type': b'application/x-www-form-urlencoded'}).addCallback(callback).addErrback(self.addErrback)
        except:
            pass

    def addErrback(self, error=None):
        pass

SKIN_VIEW = """
<screen name="TeamNitro_Config" position="0,0" size="1920,1080" title="TeamNitro ProMode" flags="wfNoBorder" backgroundColor="transparent">
    <widget source="session.VideoPicture" render="Pig" position="1186,609" size="672,389" zPosition="3" backgroundColor="transparent" />
    <ePixmap position="0,0" size="1920,1086" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/mn.png" alphatest="off" transparent="1" />
    <ePixmap position="263,106" size="800,80" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/bar.png" alphatest="off" transparent="1" />
    <widget source="Title" render="Label" position="288,111" size="752,68" zPosition="1" halign="center" font="Regular;46" backgroundColor="bglist" transparent="1" />
    <widget name="config" position="247,199" size="830,761" font="Regular;34" itemHeight="45" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/barr.png" enableWrapAround="1" transparent="1" />
    <widget name="Picture" position="1184,130" scale="1" size="671,436" alphatest="blend" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/red48x48.png" position="275,970" size="48,48" alphatest="blend" />
    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/green48x48.png" position="772,970" size="48,48" alphatest="blend" />
    <widget name="key_red" position="332,970" size="300,48" zPosition="1" font="Regular; 35" halign="left" valign="center" backgroundColor="#000000" transparent="1" foregroundColor="#FA0909" />
    <widget name="key_green" position="830,970" size="230,48" zPosition="1" font="Regular; 35" halign="left" valign="center" backgroundColor="#000000" transparent="1" foregroundColor="#05A115" />
</screen>
    """
class TeamNitro_Config(Screen, ConfigListScreen):

    def __init__(self, session, args = 0):
        self.session = session
        self.changed_screens = False
        Screen.__init__(self, session)
        self.skin = SKIN_VIEW
        self.list = []
        ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
        self.configChanged = False
        self["key_red"] = Label(_("Exit"))
        self["key_green"] = Label(_("Save Changes"))
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "EPGSelectActions"],
                {
                        "red": self.cancel,
                        "cancel": self.cancel,
                        "ok": self.keyOk,
                        "right": self.keyRight,
                        "left": self.keyLeft,
                        "green": self.keyGreen,
                }, -2)

        self["Picture"] = Pixmap()
        self.createConfigList()


    def createConfigList(self):
        self.set_DesertFHD = getConfigListEntry(_("DesertFHD "), config.plugins.TeamNitro.DesertFHD)
        self.set_RED_DRAGON_FHD = getConfigListEntry(_("RED_DRAGON_FHD"), config.plugins.TeamNitro.RED_DRAGON_FHD)
        self.set_NitroAdvanceFHD = getConfigListEntry(_("NitroAdvanceFHD"), config.plugins.TeamNitro.NitroAdvanceFHD)
        # self.set_KIII_PRO = getConfigListEntry(_("KIII_PRO "), config.plugins.TeamNitro.KIII_PRO)
        self.set_AL_AYAM_FHD = getConfigListEntry(_("AL_AYAM_FHD"), config.plugins.TeamNitro.AL_AYAM_FHD)
        self.set_fonts1 = getConfigListEntry(_("TNFont "), config.plugins.TeamNitro.fonts1)
        self.set_piconDownload = getConfigListEntry(_("Download TeamNitro Picon "), config.plugins.TeamNitro.piconDownload)
        self.set_piconpath = getConfigListEntry(_("Select Path of Picons Folder"), config.plugins.TeamNitro.piconpath)
        self.set_mounted_devices = getConfigListEntry(_("Select mount device"), config.plugins.TeamNitro.device_path)
        self.LackOfFile = ''
        self.list = []
        if  os.path.isdir("/usr/share/enigma2/DesertFHD/"):
            self.list.append(self.set_DesertFHD)
        if  os.path.isdir("/usr/share/enigma2/RED_DRAGON_FHD/"):
            self.list.append(self.set_RED_DRAGON_FHD)
        if  os.path.isdir("/usr/share/enigma2/NitroAdvanceFHD/"):
            self.list.append(self.set_NitroAdvanceFHD)
        # if  os.path.isdir("/usr/share/enigma2/KIII_PRO/"):
        #     self.list.append(self.set_KIII_PRO)
        if  os.path.isdir("/usr/share/enigma2/AL_AYAM_FHD/"):
            self.list.append(self.set_AL_AYAM_FHD)
        self.list.append(self.set_fonts1)
        self.list.append(self.set_piconDownload)
        self.list.append(self.set_piconpath)
        if config.plugins.TeamNitro.piconpath.value == 'MEDIA':
            self.list.append(self.set_mounted_devices)
        self["config"].list = self.list
        self["config"].l.setList(self.list)

    def keyGreen(self):
        for x in self['config'].list:
            x[1].save()
            configfile.save()
            self.restartGUI()


    def cancel(self):
        self.session.openWithCallback(self.cancelConfirm, MessageBox, _("DO you want close without saving the settings?"), MessageBox.TYPE_YESNO, default = False)
        # self.session.open(MessageBox, _('=======   Picon Downloads is Finished ======= '), MessageBox.TYPE_INFO, timeout=7)

    def cancelConfirm(self, result):
        if result == None or result == False:
            print("[%s]: Cancel confirmed." % cur_skin)
        else:
            print("[%s]: Cancel confirmed. Config changes will be lost." % cur_skin)
            for x in self["config"].list:
                x[1].cancel()
            self.close()


    def restartGUI(self):
        myMessage = ''
        if self.LackOfFile != '':
            cprint("missing components: %s" % self.LackOfFile)
            myMessage += _("Missing components found: %s\n\n") % self.LackOfFile
            myMessage += _("Skin will NOT work properly!!!\n\n")
        restartbox = self.session.openWithCallback(self.restartGUIcb, MessageBox, _("Restart necessary, restart GUI now?"), MessageBox.TYPE_YESNO)
        restartbox.setTitle(_("Message"))

    def restartGUIcb(self, answer):
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()

    def keyOk(self):
        sel =  self["config"].getCurrent()
        if sel != None and sel == self.set_DesertFHD:
            self.session.open(DesertFHD)

        elif sel != None and sel == self.set_RED_DRAGON_FHD:
            self.session.open(RED_DRAGON_FHD)

        elif sel != None and sel == self.set_NitroAdvanceFHD:
            self.session.open(NitroAdvanceFHD)

        elif sel != None and sel == self.set_AL_AYAM_FHD:
            self.session.open(AL_AYAM_FHD)

        # elif sel != None and sel == self.set_KIII_PRO:
        #     self.session.open(KIII_PRO)
        elif sel == self.set_fonts1:
            self.session.open(TNFonts)
        elif sel != None and sel == self.set_piconDownload:
            self.session.open(PiconDownload)
        else:
            pass