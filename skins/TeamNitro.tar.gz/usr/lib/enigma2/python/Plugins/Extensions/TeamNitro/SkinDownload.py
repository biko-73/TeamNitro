#!/usr/bin/python
# -*- coding: utf-8 -*-
#Coded By KIMO and Bahaa
#modify it if you keep the licens
###########################################
from __future__ import absolute_import
from .__init__ import _
from Components.ActionMap import ActionMap
from Components.config import *
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.Directories import *
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from Plugins.Extensions.TeamNitro.Console import Console

from smtplib import SMTP

REDC = '\033[31m'
ENDC = '\033[m'
def cprint(text):
    print(REDC + text + ENDC)

def removeunicode(data):
    try:
        try:
                data = data.encode('utf', 'ignore')
        except:
                pass
        data = data.decode('unicode_escape').encode('ascii', 'replace').replace('?', '').strip()
    except:
        pass
    return data

def trace_error():
    import sys
    import traceback
    try:
        traceback.print_exc(file=sys.stdout)
        traceback.print_exc(file=open('/tmp/TeamNitro.log', 'a'))
    except:
        pass

def logdata(label_name = '', data = None):
    try:
        data=str(data)
        fp = open('/tmp/TeamNitro.log', 'a')
        fp.write( str(label_name) + ': ' + data+"\n")
        fp.close()
    except:
        trace_error()
        pass

def dellog(label_name = "", data = None):
        try:
                if os_path.exists("/tmp/TeamNitro.log"):
                        os_remove("/tmp/TeamNitro.log")
        except:
                pass


class SkinDownload(Screen):
        skin = """
        <screen name="SkinDownload" position="0,0" size="1920,1080" title="TeamNitro Skin Download" backgroundColor="transparent">
                <widget source="session.VideoPicture" render="Pig" position="1186,609" size="672,389" zPosition="3" backgroundColor="transparent" />
                <ePixmap position="0,0" size="1920,1086" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/mn.png" alphatest="off" transparent="1" />
                <ePixmap position="263,106" size="800,80" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/bar.png" alphatest="off" transparent="1" />
                <widget name="Picture" position="1186,137" size="680,400" alphatest="blend" />
                <widget source="Title" render="Label" position="288,116" size="752,68" zPosition="1" halign="center" font="Regular;36" backgroundColor="bglist" transparent="1" />
                <widget name="menu" position="247,199" size="830,622" font="Regular; 35" itemHeight="45" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/barr.png" scrollbarMode="showNever" transparent="1" zPosition="1" />
                <eLabel text="Select and Press OK to Download Skins" position="252,856" size="820,40" font="Regular; 32" foregroundColor="#ff2525" backgroundColor="#16000000" valign="center" halign="center" transparent="1" zPosition="5" />
                <eLabel text="Select TeamNitro Skins Form the Plugin Skin Selector Main Menu" position="251,915" size="820,90" font="Regular; 38" foregroundColor="#bab329" backgroundColor="#16000000" valign="center" halign="center" transparent="1" zPosition="5" />
        </screen>
            """
        def __init__(self, session, args = 0):
                self.session = session
                self.changed_screens = False
                Screen.__init__(self, session)
                self.TeamNitro_fake_entry = NoSave(ConfigNothing())
                self["setupActions"] = ActionMap(["SetupActions"],
                {
                        "cancel": self.cancel,
                        "ok": self.DownloadSkin
                }, -1)

                self["Picture"] = Pixmap()
                list = []
                list.append((_("TeamNitro Control Center"), "ControlCenter"))
                list.append((_("NitroAdvance FHD"), "NitroAdvanceFHD"))
                list.append((_("Dragon FHD"), "DragonFHD"))
                list.append((_("Team_Nitro-by_BoHlala-V_1.2L"), "BoHlalaFHD"))
                list.append((_("Desert FHD"), "DesertFHD"))
                # list.append((_("KIII PRO"), "KIII_PRO"))
                list.append((_("AL AYAM FHD"), "AL_AYAM_FHD"))
                list.append((_("osnTeamNitroScraper"), "osnTeamNitroScraper"))
                list.append((_("osnTeamNitroPicker"), "osnTeamNitroPicker"))
                self["menu"] = MenuList(list)
                self["menu"].onSelectionChanged.append(self.Picture)
                self.onShow.append(self.Picture)
                self.onLayoutFinish.append(self.setWindowTitle)

        def setWindowTitle(self):
                self.setTitle(_("TeamNitro Skins Download"))

        def Picture(self):
                try:
                        index = self["menu"].l.getCurrentSelection()[1]
                        if index == "DragonFHD":
                                pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/DragonFHD.png')
                        elif index == "NitroAdvanceFHD":
                                pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/NitroAdvanceFHD.png')
                        elif index == "DesertFHD":
                                pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/DesertFHD.png')
                        elif index == "BoHlalaFHD":
                                pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/BoHlala_FHD.png')
                        # elif index == "KIII_PRO":
                        #         pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/KIII_PRO.png')
                        elif index == "AL_AYAM_FHD":
                                pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/AL_AYAM_FHD.png')
                        elif index == "ControlCenter":
                                pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/ControlCenter.png')
                        self['Picture'].instance.setPixmapFromFile(pic)
                except Exception as error:
                        logdata("Picture preview:", error)

        def DownloadSkin(self):
                self.session.openWithCallback(self.installSkin, MessageBox, _('Do you want to Download it now ?!!'), MessageBox.TYPE_YESNO)

        def installSkin(self, answer=False):
                try:
                        if answer:
                                cmdlist = []
                                index = self["menu"].l.getCurrentSelection()[1]
                                if index == "DragonFHD":
                                        cmdlist.append('wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerD.sh -O - | /bin/sh')
                                        self.session.open(Console, title='Download TeamNitro Skin DragonFHD', cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)

                                elif index == "NitroAdvanceFHD":
                                        cmdlist.append('wget -q "--no-check-certificate"  https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerN.sh -O - | /bin/sh ')
                                        self.session.open(Console, title='Download TeamNitro Skin NitroAdvanceFHD', cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)

                                elif index == "DesertFHD":
                                        cmdlist.append('wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerDs.sh -O - | /bin/sh')
                                        self.session.open(Console, title='Download TeamNitro Skin DesertFHD', cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)

                                elif index == "BoHlalaFHD":
                                        cmdlist.append('wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerB.sh -O - | /bin/sh')
                                        self.session.open(Console, title='Download TeamNitro Skin BoHlala_FHD', cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)

                                # elif index == "KIII_PRO":
                                #     cmdlist.append('wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerKIII.sh -O - | /bin/sh')
                                #     self.session.open(Console, title='Download TeamNitro Skin KIII_PRO', cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)

                                elif index == "AL_AYAM_FHD":
                                        cmdlist.append('wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerAL.sh -O - | /bin/sh')
                                        self.session.open(Console, title='Download TeamNitro Skin AL_AYAM_FHD', cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)

                                elif index == "osnTeamNitroScraper":
                                        cmdlist.append('/bin/sh /usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/slyk/osnTeamNitroS.sh')
                                        self.session.open(Console, title='Run TeamNitro OSN Scraper', cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)

                                elif index == "osnTeamNitroPicker":
                                        cmdlist.append('/bin/sh /usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/slyk/osnTeamNitroP.sh')
                                        self.session.open(Console, title='Run TeamNitro OSN Picker', cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)

                                elif index == "ControlCenter":
                                        cmdlist.append('wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/plugin.sh -O - | /bin/sh')
                                        self.session.open(Console, title='Download TeamNitro Control Center', cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)
                        else:
                                self.close()
                except:
                        trace_error()
                        pass


        def myCallback(self, result=None):
            return

        def cancel(self):
            self.close()