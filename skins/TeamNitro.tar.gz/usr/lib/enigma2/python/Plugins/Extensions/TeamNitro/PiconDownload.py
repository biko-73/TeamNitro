#!/usr/bin/python
# -*- coding: utf-8 -*-
#Coded By KIMO and Bahaa
#modify it if you keep the licens
###########################################
from __future__ import absolute_import
from .__init__ import _
from os.path import join, isdir, exists, isfile, split
import sys
from enigma import eTimer, getDesktop,ePicLoad, eListboxPythonMultiContent, gFont
from Components.ActionMap import ActionMap
from Components.config import *
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.AVSwitch import AVSwitch
from Components.MultiContent import MultiContentEntryText
from Screens.ChoiceBox import ChoiceBox
from Screens.InputBox import InputBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
try:
    from Screens.SkinSelection import SkinSelection
except:
    from Screens.SkinSelector import SkinSelector as SkinSelection
from Tools.LoadPixmap import LoadPixmap
from Tools import Notifications
from Tools.Notifications import AddPopup
from Tools.Directories import *
from Tools.Directories import fileExists, pathExists, createDir, resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE, SCOPE_CONFIG, SCOPE_SKIN, SCOPE_CURRENT_SKIN
import re, os, shutil
from os import listdir, remove, rename, system, path, symlink, chdir, makedirs, mkdir
from os import path as os_path, remove as os_remove, listdir as os_listdir
from os import path, remove
from Plugins.Extensions.TeamNitro.plugin import *
from Plugins.Extensions.TeamNitro.Console import Console
from smtplib import SMTP
from six.moves.urllib.request import urlretrieve
from .compat import compat_urlopen, compat_Request, compat_URLError, PY3
from .tools import getmDevices
from Components.config import config, ConfigSubsection, ConfigEnableDisable, ConfigSelection, ConfigYesNo, getConfigListEntry, configfile
from enigma import getDesktop, addFont
from .compat import PY3
#==========================================================================================#
### picon color##
# COLOREPLUGIN=resolveFilename(SCOPE_PLUGINS, "Extensions/TeamNitro/PICONS/")

# config.plugins.TeamNitro.piconpath = ConfigSelection(default = "PLUGIN", choices = [
#     ("PLUGIN", _("PLUGIN")),
#     ("MEDIA", _("MEDIA"))
#     ])

# def getmDevices():
#         myusb = myusb1 = myhdd = myhdd2 = mysdcard = mysd = myuniverse = myba = mydata =''
#         mdevices = []
#         myusb=None
#         myusb1=None
#         myhdd=None
#         myhdd2=None
#         mysdcard=None
#         mysd=None
#         myuniverse=None
#         myba=None
#         mydata=None
#         if fileExists('/proc/mounts'):
#             f = open('/proc/mounts', 'r')
#             for line in f.readlines():
#                 if line.find('/media/usb') != -1:
#                     myusb = '/media/usb'
#                 elif line.find('/media/usb1') != -1:
#                     myusb1 = '/media/usb1'
#                 elif line.find('/media/hdd') != -1:
#                     myhdd = '/media/hdd'
#                 elif line.find('/media/hdd2') != -1:
#                     myhdd2 = '/media/hdd2'
#                 elif line.find('/media/sdcard') != -1:
#                     mysdcard = '/media/sdcard'
#                 elif line.find('/media/sd') != -1:
#                     mysd = '/media/sd'
#                 elif line.find('/universe') != -1:
#                     myuniverse = '/universe'
#                 elif line.find('/media/ba') != -1:
#                     myba = '/media/ba'
#                 elif line.find('/data') != -1:
#                     mydata = '/data'
#             f.close()
#         if myusb:
#             mdevices.append((myusb, myusb))
#         if myusb1:
#             mdevices.append((myusb1, myusb1))
#         if myhdd:
#             mdevices.append((myhdd, myhdd))
#         if myhdd2:
#             mdevices.append((myhdd2, myhdd2))
#         if mysdcard:
#             mdevices.append((mysdcard, mysdcard))
#         if mysd:
#             mdevices.append((mysd, mysd))
#         if myuniverse:
#             mdevices.append((myuniverse, myuniverse))
#         if myba:
#             mdevices.append((myba, myba))
#         if mydata:
#             mdevices.append((mydata, mydata))
#         return mdevices
# mounted_devices = getmDevices()
# config.plugins.TeamNitro.device_path = ConfigSelection(choices = mounted_devices)
# if config.plugins.TeamNitro.piconpath.value == "MEDIA":
#         PATHPICON = config.plugins.TeamNitro.device_path.value
# elif config.plugins.TeamNitro.piconpath.value == "PLUGIN":
#         PATHPICON = '/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro'
#==========================================================================================#
REDC = '\033[31m'
ENDC = '\033[m'
def cprint(text):
    print(REDC + text + ENDC)

def removeunicode(data):
    try:
        try:
                data = data.encode('utf', 'ignore')
        except:
                pass
        data = data.decode('unicode_escape').encode('ascii', 'replace').replace('?', '').strip()
    except:
        pass
    return data

def trace_error():
    import sys
    import traceback
    try:
        traceback.print_exc(file=sys.stdout)
        traceback.print_exc(file=open('/tmp/TeamNitro.log', 'a'))
    except:
        pass

def logdata(label_name = '', data = None):
    try:
        data=str(data)
        fp = open('/tmp/TeamNitro.log', 'a')
        fp.write( str(label_name) + ': ' + data+"\n")
        fp.close()
    except:
        trace_error()
        pass

def dellog(label_name = "", data = None):
        try:
                if os_path.exists("/tmp/TeamNitro.log"):
                        os_remove("/tmp/TeamNitro.log")
        except:
                pass


class PiconDownload(Screen):
        skin = """
        <screen name="PiconDownload" position="0,0" size="1920,1080" title="TeamNitro Picons Download" backgroundColor="transparent">
            <widget source="session.VideoPicture" render="Pig" position="1186,609" size="672,389" zPosition="3" backgroundColor="transparent" />
            <ePixmap position="0,0" size="1920,1086" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/mn.png" alphatest="off" transparent="1" />
            <ePixmap position="263,106" size="800,80" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/bar.png" alphatest="off" transparent="1" />
            <widget name="Picture" position="1186,137" size="680,400" alphatest="blend" />
            <widget source="Title" render="Label" position="288,116" size="752,68" zPosition="1" halign="center" font="Regular;36" backgroundColor="bglist" transparent="1" />
            <widget name="menu" position="247,199" size="830,622" font="Regular; 35" itemHeight="45" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/barr.png" scrollbarMode="showNever" transparent="1" zPosition="1" />
        </screen>
            """
        def __init__(self, session, args = 0):
                self.session = session
                self.changed_screens = False
                Screen.__init__(self, session)
                self.TeamNitro_fake_entry = NoSave(ConfigNothing())
                self["setupActions"] = ActionMap(["SetupActions"],
                {
                        "cancel": self.cancel,
                        "ok": self.installPicon

                }, -1)
                self["Picture"] = Pixmap()
                list = []
                list.append((_("Black Picons"), "Black"))
                list.append((_("White Picons"), "White"))
                list.append((_("Transparent Picons"), "Transparent"))
                list.append((_("zelda Picon"), "zeldaPicon"))
                self["menu"] = MenuList(list)
                self["menu"].onSelectionChanged.append(self.Picture)
                self.onShow.append(self.Picture)
                self.onLayoutFinish.append(self.setWindowTitle)

        def setWindowTitle(self):
                self.setTitle(_("TeamNitro Satellite Provider Picons Download"))

        def Picture(self):
                try:
                        index = self["menu"].l.getCurrentSelection()[1]
                        if index == "Black":
                                pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/BlackPicon.png')
                        elif index == "White":
                                pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/WhitePicon.png')
                        elif index == "Transparent":
                                pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/TransparentPicon.png')
                        elif index == "zeldaPicon":
                                pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/zeldaPicon.png')
                        self['Picture'].instance.setPixmapFromFile(pic)
                except Exception as error:
                        logdata("Picture preview:", error)

        def installPicon(self):
                self.session.open(MessageBox, _('=======   Picon Downloads is Finished ======= '), MessageBox.TYPE_INFO, timeout=7)
                try:
                        index = self["menu"].l.getCurrentSelection()[1]
                        PICONTMP='/tmp/emu'
                        PICONTMP1='/tmp/piconCrypt'
                        PICONTMP2='/tmp/piconProv'
                        PICONTMP3='/tmp/piconSat'
                        if index == "Black":
                                os.system("wget --no-check-certificate -O '/tmp/BlackPicons2.tar.gz' 'https://github.com/biko-73/TeamNitro/raw/main/picon/BlackPicons2.tar.gz'")
                                os.system("tar -xzf /tmp/BlackPicons2.tar.gz -C /")

                        elif index == "White":
                                os.system("wget --no-check-certificate -O '/tmp/WhitePicons.tar.gz' 'https://github.com/biko-73/TeamNitro/raw/main/picon/WhitePicons.tar.gz'")
                                os.system("tar -xzf /tmp/WhitePicons.tar.gz -C /")
                        elif index == "Transparent":
                                os.system("wget --no-check-certificate -O '/tmp/TransparentPicons.tar.gz' 'https://github.com/biko-73/TeamNitro/raw/main/picon/TransparentPicons.tar.gz'")
                                os.system("tar -xzf /tmp/TransparentPicons.tar.gz -C /")
                        elif index == "zeldaPicon":
                                os.system("wget --no-check-certificate -O '/tmp/zeldaPicon.tar.gz' 'https://github.com/biko-73/TeamNitro/raw/main/picon/zeldaPicon.tar.gz'")
                                os.system("tar -xzf /tmp/zeldaPicon.tar.gz -C /")

                        if pathExists(PATHPICON + '/emu'):
                            shutil.rmtree(PATHPICON + '/emu')
                        if pathExists(PATHPICON + '/piconCrypt'):
                            shutil.rmtree(PATHPICON + '/piconCrypt')
                        if pathExists(PATHPICON + '/piconProv'):
                            shutil.rmtree(PATHPICON + '/piconProv')
                        if pathExists(PATHPICON + '/piconSat'):
                            shutil.rmtree(PATHPICON + '/piconSat')
                        shutil.move(PICONTMP, PATHPICON)
                        shutil.move(PICONTMP1, PATHPICON)
                        shutil.move(PICONTMP2, PATHPICON)
                        shutil.move(PICONTMP3, PATHPICON)
                        os.system("rm -rf /tmp/*emu*")
                        os.system("rm -rf /tmp/*piconCrypt*")
                        os.system("rm -rf /tmp/*piconProv*")
                        os.system("rm -rf /tmp/*piconSat*")
                        self.session.open(MessageBox, _('=== Picon Downloads is Started ===>> ===>>'), MessageBox.TYPE_INFO, timeout=5)
                except:
                       self.session.open(MessageBox, _('=======   Picon Downloads is Failed ======= '), MessageBox.TYPE_INFO, timeout=3)
                       pass
        def myCallback(self, result=None):
            return
        def cancel(self):
                self.close()