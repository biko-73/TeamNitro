#!/usr/bin/python
# -*- coding: utf-8 -*-
#Coded By KIMO and Bahaa
#modify it if you keep the licens
###########################################
from __future__ import absolute_import
# from .__init__ import _
from Components.ActionMap import ActionMap
from Components.config import *
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.Pixmap import Pixmap
from Screens.Screen import Screen
from Tools.Directories import *
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_CONFIG, SCOPE_SKIN
import re, os, shutil
from os import listdir, remove, rename, path, symlink, chdir, mkdir
from os import path, remove
from Components.config import config, ConfigSelection, ConfigYesNo, getConfigListEntry, configfile
from Plugins.Extensions.TeamNitro.plugin import *

cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')

REDC = '\033[31m'
ENDC = '\033[m'
def cprint(text):
    print(REDC + text + ENDC)

class DesertFHD(Screen, ConfigListScreen):

    skin = """

        <screen name="DesertFHD" position="0,0" size="1920,1080" title="DesertFHD PRO-MOD" backgroundColor="transparent">
            <widget source="session.VideoPicture" render="Pig" position="1186,609" size="672,389" zPosition="3" backgroundColor="transparent" />
            <ePixmap position="0,0" size="1920,1086" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/mn.png" alphatest="off" transparent="1" />
            <ePixmap position="263,106" size="800,80" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/bar.png" alphatest="off" transparent="1" />
            <widget source="Title" render="Label" position="288,111" size="752,68" zPosition="1" halign="center" font="Regular;46" backgroundColor="bglist" transparent="1" />
            <widget name="config" position="247,199" size="830,761" font="Regular;34" itemHeight="45" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/barr.png" enableWrapAround="1" transparent="1" />
            <widget name="Picture" position="1184,130" scale="1" size="671,436" alphatest="blend" />
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/red48x48.png" position="275,970" size="48,48" alphatest="blend" />
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/green48x48.png" position="772,970" size="48,48" alphatest="blend" />
            <widget name="key_red" position="332,970" size="300,48" zPosition="1" font="Regular; 35" halign="left" valign="center" backgroundColor="#000000" transparent="1" foregroundColor="#FA0909" />
            <widget name="key_green" position="830,970" size="230,48" zPosition="1" font="Regular; 35" halign="left" valign="center" backgroundColor="#000000" transparent="1" foregroundColor="#05A115" />
        </screen>
    """

    def __init__(self, session, args = 0):
        self.session = session
        self.changed_screens = False
        Screen.__init__(self, session)
        self.start_skin = config.skin.primary_skin.value
        if self.start_skin != "skin.xml":
            self.getInitConfig()
        self.list = []
        ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
        self.configChanged = False
        self["key_red"] = Label(_("Cancel"))
        self["key_green"] = Label(_("Save Changes"))
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "EPGSelectActions"],
                {
                        "green": self.keyGreen,
                        "red": self.cancel,
                        "cancel": self.cancel,
                        "right": self.keyRight,
                        "left": self.keyLeft,
                }, -2)
        self["Picture"] = Pixmap()
        self.createConfigList()

    def getInitConfig(self):
        global cur_skin
        cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
        self.title = _("PRO SKINS Setup")
        self.skin_base_dir = "/usr/share/enigma2/DesertFHD/"
        cprint("self.skin_base_dir=%s, skin=%s, currentSkin=%s" % (self.skin_base_dir, config.skin.primary_skin.value, cur_skin))
        self.default_font_file = "font_Original.xml"
        self.font_file = "skin_user_font.xml"
        self.default_color_file = "color_Original.xml"
        self.color_file = "skin_user_color.xml"
#DesertFHD
        self.default_DesertFHD_file = "DesertFHD_Original.xml"
        self.DesertFHD_file = "skin_user_DesertFHD.xml"
        current, choices = self.getSettings(self.default_DesertFHD_file, self.DesertFHD_file)
        self.TeamNitro_DesertFHD = NoSave(ConfigSelection(default=current, choices = choices))
#Basic
        self.default_Basic_file = "Basic_Original.xml"
        self.Basic_file = "skin_user_Basic.xml"
        current, choices = self.getSettings(self.default_Basic_file, self.Basic_file)
        self.TeamNitro_Basic = NoSave(ConfigSelection(default=current, choices = choices))
#TNPosterX
        self.default_TNPosterX_file = "TNPosterX_Original.xml"
        self.TNPosterX_file = "skin_user_TNPosterX.xml"
        current, choices = self.getSettings(self.default_TNPosterX_file, self.TNPosterX_file)
        self.TeamNitro_TNPosterX = NoSave(ConfigSelection(default=current, choices = choices))
#xtraEvent
        self.default_xtraEvent_file = "xtraEvent_Original.xml"
        self.xtraEvent_file = "skin_user_xtraEvent.xml"
        current, choices = self.getSettings(self.default_xtraEvent_file, self.xtraEvent_file)
        self.TeamNitro_xtraEvent = NoSave(ConfigSelection(default=current, choices = choices))
#PluginBrowser
        self.default_PluginBrowser_file = "PluginBrowser_Original.xml"
        self.PluginBrowser_file = "skin_user_PluginBrowser.xml"
        current, choices = self.getSettings(self.default_PluginBrowser_file, self.PluginBrowser_file)
        self.TeamNitro_PluginBrowser = NoSave(ConfigSelection(default=current, choices = choices))
#osnTeamNitro
        self.default_osnTeamNitro_file = "osnTeamNitro_Original.xml"
        self.osnTeamNitro_file = "skin_user_osnTeamNitro.xml"
        current, choices = self.getSettings(self.default_osnTeamNitro_file, self.osnTeamNitro_file)
        self.TeamNitro_osnTeamNitro = NoSave(ConfigSelection(default=current, choices = choices))
# myatile
        myatile_active = self.getmyAtileState()
        self.TeamNitro_active = NoSave(ConfigYesNo(default=True))
        self.TeamNitro_fake_entry = NoSave(ConfigNothing())




    def getSettings(self, default_file, user_file):
        # default setting
        default = ("default", _("Default"))

        # search typ
        styp = default_file.replace('_Original.xml', '')
        search_str = '%s_' % styp

        # possible setting
        choices = []
        files = listdir(self.skin_base_dir)
        if path.exists(self.skin_base_dir + 'allScreens/%s/' % styp):
            files += listdir(self.skin_base_dir + 'allScreens/%s/' % styp)
        for f in sorted(files, key=str.lower):
            if f.endswith('.xml') and f.startswith(search_str):
                friendly_name = f.replace(search_str, "").replace(".xml", "").replace("_", " ")
                if path.exists(self.skin_base_dir + 'allScreens/%s/%s' %(styp, f)):
                    choices.append((self.skin_base_dir + 'allScreens/%s/%s' %(styp, f), friendly_name))
                else:
                    choices.append((self.skin_base_dir + f, friendly_name))
        choices.append(default)

        # current setting
        myfile = self.skin_base_dir + user_file
        current = ''
        if not path.exists(myfile):
            if path.exists(self.skin_base_dir + default_file):
                if path.islink(myfile):
                    remove(myfile)
                chdir(self.skin_base_dir)
                symlink(default_file, user_file)
            elif path.exists(self.skin_base_dir + 'allScreens/%s/%s' % (styp, default_file)):
                if path.islink(myfile):
                    remove(myfile)
                chdir(self.skin_base_dir)
                symlink(self.skin_base_dir + 'allScreens/%s/%s' %(styp, default_file), user_file)
            else:
                current = None
        if current is None:
            current = default
        else:
            filename = path.realpath(myfile)
            friendly_name = path.basename(filename).replace(search_str, "").replace(".xml", "").replace("_", " ")
            current = (filename, friendly_name)

        return current[0], choices
        if path.exists(self.skin_base_dir + "mySkin_off"):
            if not path.exists(self.skin_base_dir + "TeamNitro_Selections"):
                chdir(self.skin_base_dir)
                try:
                    rename("mySkin_off", "TeamNitro_Selections")
                except:
                    pass

    def createConfigList(self):
        self.set_DesertFHD = getConfigListEntry(_("DesertFHD:"), self.TeamNitro_DesertFHD)
        self.set_Basic = getConfigListEntry(_("Basic:"), self.TeamNitro_Basic)
        self.set_TNPosterX = getConfigListEntry(_("TNPosterX:"), self.TeamNitro_TNPosterX)
        self.set_xtraEvent = getConfigListEntry(_("xtraEvent:"), self.TeamNitro_xtraEvent)
        self.set_PluginBrowser = getConfigListEntry(_("PluginBrowser:"), self.TeamNitro_PluginBrowser)
        self.set_osnTeamNitro = getConfigListEntry(_("osnTeamNitro:"), self.TeamNitro_osnTeamNitro)
        self.set_myatile = getConfigListEntry(_("Enable %s pro:") % cur_skin, self.TeamNitro_active)
        self.LackOfFile = ''
        self.list = []



        if len(self.TeamNitro_DesertFHD.choices)>1:
            self.list.append(self.set_DesertFHD)
        if len(self.TeamNitro_Basic.choices)>1:
            self.list.append(self.set_Basic)
        if len(self.TeamNitro_TNPosterX.choices)>1:
            self.list.append(self.set_TNPosterX)
        if len(self.TeamNitro_xtraEvent.choices)>1:
            self.list.append(self.set_xtraEvent)
        if len(self.TeamNitro_PluginBrowser.choices)>1:
            self.list.append(self.set_PluginBrowser)
        if len(self.TeamNitro_osnTeamNitro.choices)>1:
            self.list.append(self.set_osnTeamNitro)
        else:
              pass
        self["config"].list = self.list
        self["config"].l.setList(self.list)

    def changedEntry(self):
        self.configChanged = True
        if self["config"].getCurrent() == self.set_DesertFHD:
            self.setPicture(self.TeamNitro_DesertFHD.value)
        elif self["config"].getCurrent() == self.set_Basic:
            self.setPicture(self.TeamNitro_Basic.value)
        elif self["config"].getCurrent() == self.set_TNPosterX:
            self.setPicture(self.TeamNitro_TNPosterX.value)
        elif self["config"].getCurrent() == self.set_xtraEvent:
            self.setPicture(self.TeamNitro_xtraEvent.value)
        elif self["config"].getCurrent() == self.set_PluginBrowser:
            self.setPicture(self.TeamNitro_PluginBrowser.value)
        elif self["config"].getCurrent() == self.set_osnTeamNitro:
            self.setPicture(self.TeamNitro_osnTeamNitro.value)
        elif self["config"].getCurrent() == self.set_myatile:
            if self.TeamNitro_active.value == True:
                self.createConfigList()
            else:
                pass
            self.createConfigList()

    def selectionChanged(self):
        if self["config"].getCurrent() == self.set_DesertFHD:
            self.setPicture(self.TeamNitro_DesertFHD.value)
        elif self["config"].getCurrent() == self.set_Basic:
            self.setPicture(self.TeamNitro_Basic.value)
        elif self["config"].getCurrent() == self.set_TNPosterX:
            self.setPicture(self.TeamNitro_TNPosterX.value)
        elif self["config"].getCurrent() == self.set_xtraEvent:
            self.setPicture(self.TeamNitro_xtraEvent.value)
        elif self["config"].getCurrent() == self.set_PluginBrowser:
            self.setPicture(self.TeamNitro_PluginBrowser.value)
        elif self["config"].getCurrent() == self.set_osnTeamNitro:
            self.setPicture(self.TeamNitro_osnTeamNitro.value)
        else:
            self["Picture"].hide()

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.createConfigList()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.createConfigList()

    def cancel(self):
        self.keyGreen()

    def getmyAtileState(self):
        chdir(self.skin_base_dir)
        if path.exists("mySkin"):
            return True
        else:
            return False

    def setPicture(self, f):
        pic = f.split('/')[-1].replace(".xml", ".png")
        preview = self.skin_base_dir + "preview/preview_" + pic
        if path.exists(preview):
            self["Picture"].instance.setPixmapFromFile(preview)
            self["Picture"].show()
        else:
            self["Picture"].hide()


    def keyGreen(self):
        if self["config"].isChanged():
            for x in self["config"].list:
                x[1].save()
                configfile.save()
            chdir(self.skin_base_dir)
            self.makeSettings(self.TeamNitro_DesertFHD, self.DesertFHD_file)
            self.makeSettings(self.TeamNitro_Basic, self.Basic_file)
            self.makeSettings(self.TeamNitro_TNPosterX, self.TNPosterX_file)
            self.makeSettings(self.TeamNitro_xtraEvent, self.xtraEvent_file)
            self.makeSettings(self.TeamNitro_PluginBrowser, self.PluginBrowser_file)
            self.makeSettings(self.TeamNitro_osnTeamNitro, self.osnTeamNitro_file)

            if not path.exists("mySkin_off"):
                mkdir("mySkin_off")
                print("makedir mySkin_off")
            if self.TeamNitro_active.value:
                if not path.exists("mySkin") and path.exists("mySkin_off"):
                    symlink("mySkin_off", "mySkin")
            else:
                if path.exists("mySkin"):
                    if path.exists("mySkin_off"):
                        if path.islink("mySkin"):
                            remove("mySkin")
                        else:
                            shutil.rmtree("mySkin")
                    else:
                        rename("mySkin", "mySkin_off")
            self.update_user_skin()
            self.close()
        elif  config.skin.primary_skin.value != self.start_skin:
            self.update_user_skin()
            self.close()
        else:
            if self.changed_screens:
                self.update_user_skin()
                self.close()
            else:
                self.close()

    def makeSettings(self, config_entry, user_file):
        if path.exists(user_file):
            remove(user_file)
        if path.islink(user_file):
            remove(user_file)
        if config_entry.value != 'default':
            symlink(config_entry.value, user_file)

    def TeamNitroScreenCB(self):
        self.changed_screens = True
        self["config"].setCurrentIndex(0)

    def update_user_skin(self):
        global cur_skin
        user_skin_file = resolveFilename(SCOPE_CONFIG, 'skin_user_' + cur_skin + '.xml')
        if path.exists(user_skin_file):
            remove(user_skin_file)
        cprint("update_user_skin.self.TeamNitro_active.value")
        user_skin = ""
        if path.exists(self.skin_base_dir + self.DesertFHD_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.DesertFHD_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + self.Basic_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.Basic_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + self.TNPosterX_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.TNPosterX_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + self.xtraEvent_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.xtraEvent_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + self.PluginBrowser_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.PluginBrowser_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + self.osnTeamNitro_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.osnTeamNitro_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + 'mySkin'):
            for f in listdir(self.skin_base_dir + "mySkin/"):
                user_skin = user_skin + self.readXMLfile(self.skin_base_dir + "mySkin/" + f, 'screen')
        if user_skin != '':
            user_skin = "<skin>\n" + user_skin
            user_skin = user_skin + "</skin>\n"
            with open(user_skin_file, "w") as myFile:
                cprint("update_user_skin.self.TeamNitro_active.value write myFile")
                myFile.write(user_skin)
                myFile.flush()
                myFile.close()
        self.checkComponent(user_skin, 'render', resolveFilename(SCOPE_PLUGINS, '../Components/Renderer/') )
        self.checkComponent(user_skin, 'Convert', resolveFilename(SCOPE_PLUGINS, '../Components/Converter/') )
        self.checkComponent(user_skin, 'pixmap', resolveFilename(SCOPE_SKIN, '') )

    def checkComponent(self, myContent, look4Component, myPath):
        def updateLackOfFile(name, mySeparator =', '):
                cprint("Missing component found:%s\n" % name)
                if self.LackOfFile == '':
                        self.LackOfFile = name
                else:
                        self.LackOfFile += mySeparator + name

        r=re.findall( r' %s="([a-zA-Z0-9_/\.]+)" ' % look4Component, myContent )
        r=list(set(r))

        cprint("Found %s:\n" % (look4Component))
        print(r)
        if r:
                for myComponent in set(r):
                        if look4Component == 'pixmap':
                                if myComponent.startswith('/'):
                                        if not path.exists(myComponent):
                                                updateLackOfFile(myComponent, '\n')
                                else:
                                        if not path.exists(myPath + myComponent):
                                                updateLackOfFile(myComponent)
                        else:
                                if not path.exists(myPath + myComponent + ".pyo") and not path.exists(myPath + myComponent + ".py") and not path.exists(myPath + myComponent + ".pyc"):
                                        updateLackOfFile(myComponent)
        return

    def save(self):
        for x in self['config'].list:
            x[1].save()
            configfile.save()

    def readXMLfile(self, XMLfilename, XMLsection):
        myPath=path.realpath(XMLfilename)
        if not path.exists(myPath):
                remove(XMLfilename)
                return ''
        filecontent = ''
        if XMLsection == 'ALLSECTIONS':
                sectionmarker = True
        else:
                sectionmarker = False
        with open (XMLfilename, "r") as myFile:
                for line in myFile:
                        if line.find('<skin>') >= 0 or line.find('</skin>') >= 0:
                                continue
                        if line.find('<%s' %XMLsection) >= 0 and sectionmarker == False:
                                sectionmarker = True
                        elif line.find('</%s>' %XMLsection) >= 0 and sectionmarker == True:
                                sectionmarker = False
                                filecontent = filecontent + line
                        if sectionmarker == True:
                                filecontent = filecontent + line
                myFile.close()
        return filecontent