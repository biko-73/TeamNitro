#!/bin/sh
#

# OSN Universal toppicks V1 (C) kiddac. 2024

python /usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/slyk/scraper.py

echo 1 > /proc/sys/vm/drop_caches
echo 2 > /proc/sys/vm/drop_caches
echo 3 > /proc/sys/vm/drop_caches

if test -f /usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/slyk/all_channels_data.json; then
    python /usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/slyk/picker.py
fi
echo "#########################################################"
echo "#           OSN TeamNitro Update Successfully            #"
echo "#  Now Please RUN osnTeamNitroPicker from Control Center #"
echo "#             BY TeamNitro - support on                 #"
echo "#       https://www.tunisia-sat.com/forums/forums       #"
echo "#########################################################"
else
echo "   >>>>   INSTALLATION FAILED !   <<<<"
fi;
echo '**************************************************'
echo '**                   FINISHED                   **'
echo '**************************************************'
exit 0
