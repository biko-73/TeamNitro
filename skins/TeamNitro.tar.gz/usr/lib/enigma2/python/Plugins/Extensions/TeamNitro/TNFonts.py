# -*- coding: utf-8 -*-
from __future__ import print_function
# from .__init__ import _
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigSubsection, ConfigEnableDisable, ConfigSelection, ConfigYesNo, getConfigListEntry, configfile
from Components.Label import Label
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Components.Pixmap import Pixmap
from enigma import getDesktop, addFont
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from os import path as os_path, remove as os_remove, listdir as os_listdir
from twisted.web.client import getPage, error
from .compat import PY3
from .Console import Console
import os

PLUGINPATH = resolveFilename(SCOPE_PLUGINS, "Extensions/TeamNitro")

def trace_error():
        import sys
        import traceback
        try:
                traceback.print_exc(file=sys.stdout)
                traceback.print_exc(file=open("/tmp/TNFonts.log", "a"))
        except:
                pass

def logdata(label_name = "", data = None):
        try:
                data=str(data)
                fp = open("/tmp/TNFonts.log", "a")
                fp.write( str(label_name) + " : " + data+"\n")
                fp.close()
        except:
                trace_error()    
                pass

def dellog(label_name = "", data = None):
        try:
                if os_path.exists("/tmp/TNFonts.log"):
                        os_remove("/tmp/TNFonts.log")
        except:
                pass

GETPath = os_path.join(PLUGINPATH, "fonts")  # Keep this for font-related files

# Check if the font_default.otf exists in the TNFonts folder
if os_path.exists(os_path.join(GETPath, "font_default.otf")):  # Font path logic
    try:
        DEFAULTFont = os_path.join(GETPath, "font_default.otf")  # Correct path for default font
    except Exception as error:
        trace_error()
else:
    logdata("TNFonts: Missing DEFAULT Font")

fonts = []
try:
    if os_path.exists(GETPath):
        for fontName in os_listdir(GETPath):
            if fontName.endswith(".ttf") or fontName.endswith(".otf"):
                fontNamePath = os_path.join(GETPath, fontName)
                fontName = fontName[:-4]  # Remove the file extension
                fonts.append((fontNamePath, fontName))
except Exception as error:
    trace_error()

fonts = sorted(fonts, key=lambda x: x[1])

config.TNFonts = ConfigSubsection()
config.TNFonts.active = ConfigEnableDisable(default=True)
config.TNFonts.fonts = ConfigSelection(default=DEFAULTFont, choices=fonts)

FONTSTYPE = config.TNFonts.fonts.value


class TNFonts(ConfigListScreen, Screen):
        skin = """

                <screen name="TNFonts" position="0,0" size="1920,1080" title="TeamNitro Fonts Control Center">
                <widget source="session.VideoPicture" render="Pig" position="1186,609" size="672,389" zPosition="3" backgroundColor="transparent" />
                <ePixmap position="0,0" size="1920,1086" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/mn.png" alphatest="blend" transparent="1" />
                <ePixmap position="263,106" size="800,80" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/bar.png" alphatest="blend" transparent="1" />
                <widget source="Title" render="Label" position="288,111" size="752,68" zPosition="1" halign="center" font="Regular;46" backgroundColor="bglist" transparent="1" />
                <widget name="config" position="247,199" size="830,761" font="Regular;34" itemHeight="45" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/barr.png" enableWrapAround="1" transparent="1" />
                <widget name="Picture" position="1184,130" scale="1" size="671,436" alphatest="blend" />
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/red48x48.png" position="275,970" size="48,48" alphatest="blend" zPosition="11" />
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/green48x48.png" position="772,970" size="48,48" alphatest="blend" zPosition="11" />
                <!-- key_red -->
                <widget render="Label" source="key_red" position="332,970" size="300,44" zPosition="11" borderColor="black" borderWidth="2" font="Regular; 35" halign="left" valign="center" foregroundColor="red" backgroundColor="bgmain" transparent="1" />
                <widget source="key_red" render="Label" position="332,970" size="300,44" zPosition="11" font="Regular; 35" valign="center" halign="left" backgroundColor="background" transparent="1" foregroundColor="red" borderWidth="2" borderColor="black" />
                <widget name="key_red" borderColor="black" borderWidth="2" position="332,970" size="300,44" zPosition="11" font="Regular; 35" halign="left" valign="center" foregroundColor="#ff0000" backgroundColor="bglist" transparent="1" />
                <!-- /* key_green -->
                <widget render="Label" source="key_green" position="830,970" size="319,44" zPosition="11" font="Regular; 35" borderColor="black" borderWidth="2" halign="left" valign="center" foregroundColor="#ff00" backgroundColor="bgmain" transparent="1" />
                <widget source="key_green" render="Label" position="830,970" size="319,44" zPosition="11" font="Regular; 35" valign="center" halign="left" backgroundColor="background" transparent="1" foregroundColor="#ff00" borderWidth="2" borderColor="black" />
                <widget name="key_green" borderColor="black" borderWidth="2" position="830,970" size="319,44" zPosition="11" font="Regular; 35" halign="left" valign="center" foregroundColor="#ff00" backgroundColor="bglist" transparent="1" />
                <!-- key_red -->
                </screen>"""

        def __init__(self, session):
                dellog()
                Screen.__init__(self, session)
                self.session = session
                self.skin = TNFonts.skin
                self.configChanged = False
                list = []
                ConfigListScreen.__init__(self, list)
                self["config"].list = list
                self["key_red"] = StaticText(_("الغاء (Cancel)"))
                self["key_green"] = StaticText(_("حفظ (Save)"))
                self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], 
                        {
                                "cancel": self.keyClose,
                                "green": self.keySave,
                        }, -1)

                self.set_active_value = config.TNFonts.active.value
                self.set_fonts_value = config.TNFonts.fonts.value

                self["Picture"] = Pixmap()
                self.createConfigList()

        def createConfigList(self):
                self.configChanged = True
                self.set_active = getConfigListEntry(_("Enable/Disable"), config.TNFonts.active)
                self.set_fonts = getConfigListEntry(_("Choose Font Type"), config.TNFonts.fonts)

                list = []
                list.append(self.set_active)
                list.append(self.set_fonts)

                self["config"].list = list
                self["config"].l.setList(list)
                self["config"].onSelectionChanged.append(self.Picture)

        def Picture(self):
                #try:
                        cur = self["config"].getCurrent()
                        if cur == self.set_fonts:
                                # Extract only the font name (without path and extension)
                                font_name = os.path.basename(config.TNFonts.fonts.value)  # Get the font name with extension
                                font_name_without_extension = os.path.splitext(font_name)[0]  # Remove extension (e.g., .ttf or .otf)

                                # Build the preview path using the font name (without extension)
                                preview = os.path.join(PLUGINPATH, "images/preview", "{}.png".format(font_name_without_extension))

                                # Debugging output to check the constructed preview path
                                print("Preview path:", preview)
                                print("File exists:", os.path.exists(preview))  # Check if file really exists

                                if os.path.exists(preview):
                                        self["Picture"].instance.setPixmapFromFile(preview)
                                        self["Picture"].show()
                                else:
                                        logdata("Picture preview: No preview image")
                        else:
                                self["Picture"].hide()
        def keyLeft(self):
                ConfigListScreen.keyLeft(self)
                self.Picture()
                self.createConfigList()

        def keyRight(self):
                ConfigListScreen.keyRight(self)
                self.createConfigList()
                self.Picture()

        def activate(self):
                try:
                        addFont(FONTSTYPE, "ArabicFont", 100, 1)
                        logdata("activate: arabic font added successfully")
                except Exception as error:
                        logdata("activate:", error)
                self["key_red"].setText(_("الغاء (Cancel)"))
                self["key_green"].setText(_("حفظ (Save)"))
                self.setTitle("Arabic Fonts")

        def keySave(self):
                # Save all config changes
                for x in self["config"].list:
                        x[1].save()
                configfile.save()

                # Log the selected font after saving the configuration
                logdata("Selected font after save:", config.TNFonts.fonts.value)

                # Apply the selected font
                try:
                        selected_font = config.TNFonts.fonts.value  # Get the updated font value
                        addFont(selected_font, "ArabicFont", 100, 1)
                        logdata("Font applied successfully:", selected_font)
                except Exception as error:
                        logdata("Error applying font:", error)

                # Check if settings were changed
                if (self.set_active_value != config.TNFonts.active.value or 
                        self.set_fonts_value != config.TNFonts.fonts.value):
                        self.session.openWithCallback(self.restart, MessageBox, 
                        _("The settings have been changed, do you want to restart Enigma now?\n تم تغيير الإعدادات ، هل تريد إعادة تشغيل الانجيما الآن؟"))
                else:
                        self.close(True)


        def restart(self, answer = None):
                if answer:
                        self.session.open(TryQuitMainloop, 3)
                        return
                self.close(True)

        def keyClose(self):
                for x in self["config"].list:
                        x[1].cancel()
                self.close()


def sessionstart(reason, **kwargs):
                if reason == 0:
                        if config.TNFonts.fonts.value == False:
                                pass
                        else:
                                try:
                                        addFont(FONTSTYPE, "ArabicFont", 100, 1)
                                        logdata("activate: arabic font added successfully")
                                except Exception as error:
                                        logdata("activate:", error)