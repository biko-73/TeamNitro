#!/usr/bin/python
# -*- coding: utf-8 -*-

# for localized messages
from . import _

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from Screens.Screen import Screen


class TeamNitro_About(Screen):
    skin = """
        <screen name="TN_About" position="0,0" size="1920,1080" backgroundColor="#232323" flags="wfNoBorder">
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/mn.png" position="0,0" size="1920,1080" alphatest="blend" />
            <widget source="session.VideoPicture" render="Pig" position="1186,560" size="680,400" zPosition="3" backgroundColor="transparent2" />
            <widget source="Title" render="Label" position="63,25" size="1790,68" zPosition="1" halign="center" font="Regular;46" foregroundColor="#ffffff" backgroundColor="#232323" transparent="1" />
            <widget name="about" position="50,145" size="1065,810" font="Regular;35" foregroundColor="#ffffff" backgroundColor="#232323" transparent="1" zPosition="2" />
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/red48x48.png" position="65,1005" size="48,48" alphatest="blend" />
            <widget source="key_red" render="Label" position="113,1005" size="300,48" zPosition="1" font="Regular; 35" halign="center" valign="center" backgroundColor="#000000" transparent="1" foregroundColor="#FA0909" />
        </screen>
    
    """
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self.setup_title = _('About TeamNitro')

        self['actions'] = ActionMap(['SetupActions'], {
            'ok': self.quit,
            'cancel': self.quit,
            'menu': self.quit}, -2)
        self['key_red'] = StaticText(_('Close'))
        self['about'] = Label('')
        self.onFirstExecBegin.append(self.createSetup)
        self.onLayoutFinish.append(self.__layoutFinished)

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def createSetup(self):
        self.credit = 'TeamNitro Plugin Develop by - KIMOO\n\n'
        self['about'].setText(self.credit)

    def quit(self):
        self.close()




