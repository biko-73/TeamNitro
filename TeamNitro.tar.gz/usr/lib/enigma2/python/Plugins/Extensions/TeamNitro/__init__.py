# -*- coding: utf-8 -*-
from __future__ import print_function
from Components.Language import language
from Components.config import config, ConfigSubsection, ConfigSelection, ConfigNumber, ConfigSelectionNumber, ConfigYesNo, ConfigText, ConfigInteger
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import os, gettext
from os import path
import gettext
try:
	from boxbranding import getBoxType
except:
	pass
PluginLanguageDomain = 'en'
PluginLanguagePath = 'Extensions/NitroAdvanceFHD/language'

def localeInit():
    lang = language.getLanguage()[:2]
    os.environ['LANGUAGE'] = lang
    print('[WebInterface] set language to ', lang)
    gettext.bindtextdomain(PluginLanguageDomain, resolveFilename(SCOPE_PLUGINS, PluginLanguagePath))


def _(txt):
    t = gettext.dgettext(PluginLanguageDomain, txt)
    if t == txt:
        print('[%s] fallback to default translation for %s' % (PluginLanguageDomain, txt))
        t = gettext.gettext(txt)
    return t


localeInit()
language.addCallback(localeInit)

def initWeatherConfig():
	config.plugins.TeamNitroWeather = ConfigSubsection()

	#MetrixWeather

	config.plugins.TeamNitroWeather.enabled = ConfigYesNo(default=True)
	config.plugins.TeamNitroWeather.type = ConfigYesNo(default=False)
	config.plugins.TeamNitroWeather.animationspeed = ConfigSelection(default="100", choices=[("0", _("Off")), ("20", _("+ 4")), ("40", _("+ 3")), ("60", _("+ 2")), ("80", _("+ 1")), ("100", _("Default")), ("125", _("- 1")), ("150", _("- 2")), ("200", _("- 3")), ("300", _("- 4"))])
	config.plugins.TeamNitroWeather.tempplus = ConfigYesNo(default=False)
	config.plugins.TeamNitroWeather.MoviePlayer = ConfigYesNo(default=True)
	config.plugins.TeamNitroWeather.verifyDate = ConfigYesNo(default=True)
	config.plugins.TeamNitroWeather.refreshInterval = ConfigSelectionNumber(0, 1440, 30, default=120, wraparound=True)
	config.plugins.TeamNitroWeather.woeid = ConfigNumber(default=2911298)
	config.plugins.TeamNitroWeather.apikey = ConfigText(default="a4bd84726035d0ce2c6185740617d8c5")
	BoxType = getBoxType()
	if BoxType.startswith("beyonwiz"):
		# Beyonwiz - marketed only in Australia
		weathercity = "Sydney, Australia"
	else:
		weathercity = "Hamburg, Germany"
	config.plugins.TeamNitroWeather.weathercity = ConfigText(default=weathercity, visible_width=250, fixed_size=False)
	config.plugins.TeamNitroWeather.tempUnit = ConfigSelection(default="Celsius", choices=[
		("Celsius", _("Celsius")),
		("Fahrenheit", _("Fahrenheit"))
	])
	config.plugins.TeamNitroWeather.weatherservice = ConfigSelection(default="MSN", choices=[
		("MSN", _("MSN")),
		("openweather", _("openweather"))
	])
	config.plugins.TeamNitroWeather.forecast = ConfigSelectionNumber(0, 3, 1, default=1, wraparound=True)
	config.plugins.TeamNitroWeather.weekday = ConfigYesNo(default=False)
	config.plugins.TeamNitroWeather.detail = ConfigYesNo(default=False)

	## RENDERER CONFIG:

	config.plugins.TeamNitroWeather.currentWeatherDataValid = ConfigNumber(default=0)
	config.plugins.TeamNitroWeather.currentLocation = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.currentWeatherCode = ConfigText(default="(")
	config.plugins.TeamNitroWeather.currentWeatherText = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.currentWeatherTemp = ConfigText(default="0")
	config.plugins.TeamNitroWeather.currentWeatherhumidity = ConfigText(default="0")
	config.plugins.TeamNitroWeather.currentWeatherwinddisplay = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.currentWeatherwindspeed = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.currentWeathershortday = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.currentWeatherdate = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.currentWeatherday = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.currentWeatherobservationtime = ConfigText(default="0")

	config.plugins.TeamNitroWeather.currentWeatherfeelslike = ConfigText(default="0")
	config.plugins.TeamNitroWeather.forecastTodayCode = ConfigText(default="(")
	config.plugins.TeamNitroWeather.forecastTodayText = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.forecastTodayTempMin = ConfigText(default="0")
	config.plugins.TeamNitroWeather.forecastTodayTempMax = ConfigText(default="0")

	config.plugins.TeamNitroWeather.forecastTomorrowCode = ConfigText(default="(")
	config.plugins.TeamNitroWeather.forecastTomorrowText = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.forecastTomorrowTempMin = ConfigText(default="0")
	config.plugins.TeamNitroWeather.forecastTomorrowTempMax = ConfigText(default="0")
	config.plugins.TeamNitroWeather.forecastTomorrowdate = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.forecastTomorrowday = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.forecastTomorrowshortday = ConfigText(default="N/A")

	config.plugins.TeamNitroWeather.forecastTomorrowCode2 = ConfigText(default="(")
	config.plugins.TeamNitroWeather.forecastTomorrowText2 = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.forecastTomorrowTempMin2 = ConfigText(default="0")
	config.plugins.TeamNitroWeather.forecastTomorrowTempMax2 = ConfigText(default="0")
	config.plugins.TeamNitroWeather.forecastTomorrowdate2 = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.forecastTomorrowday2 = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.forecastTomorrowshortday2 = ConfigText(default="N/A")

	config.plugins.TeamNitroWeather.forecastTomorrowCode3 = ConfigText(default="(")
	config.plugins.TeamNitroWeather.forecastTomorrowText3 = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.forecastTomorrowTempMin3 = ConfigText(default="0")
	config.plugins.TeamNitroWeather.forecastTomorrowTempMax3 = ConfigText(default="0")
	config.plugins.TeamNitroWeather.forecastTomorrowdate3 = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.forecastTomorrowday3 = ConfigText(default="N/A")
	config.plugins.TeamNitroWeather.forecastTomorrowshortday3 = ConfigText(default="N/A")