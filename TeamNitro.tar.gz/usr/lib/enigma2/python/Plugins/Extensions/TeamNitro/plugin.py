#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import absolute_import
from .__init__ import _
from enigma import eTimer, getDesktop,ePicLoad, eListboxPythonMultiContent, gFont
from Components.ActionMap import ActionMap
from Tools.Directories import *
from Components.config import *
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.AVSwitch import AVSwitch
from Components.MultiContent import MultiContentEntryText
from Plugins.Plugin import PluginDescriptor
from Screens.SkinSelector import SkinSelector
from Screens.InputBox import InputBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Tools.LoadPixmap import LoadPixmap
from Tools import Notifications
from Tools.Notifications import AddPopup
from Components.config import config, ConfigSelectionNumber, getConfigListEntry, ConfigSelection, ConfigYesNo, ConfigSubsection, ConfigText, configfile, ConfigNumber, NoSave, ConfigNothing 
from os import listdir, remove, rename, system, path, symlink, chdir, makedirs, mkdir
from os import path as os_path, remove as os_remove
from os import path, remove
from Tools.Directories import fileExists, pathExists, createDir, resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE, SCOPE_CONFIG, SCOPE_SKIN, SCOPE_CURRENT_SKIN
# import requests
import shutil
import re, os, shutil
from Plugins.Extensions.TeamNitro.Console2 import Console2
from Plugins.Extensions.TeamNitro.Console import Console
from Plugins.Extensions.TeamNitro.WeatherMSN import WeatherMSN
from Plugins.Extensions.TeamNitro.about import TeamNitro_About

from smtplib import SMTP
from six.moves.urllib.request import urlretrieve
from .compat import compat_urlopen, compat_Request, compat_URLError, PY3
from .tools import getmDevices

cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')

reswidth = getDesktop(0).size().width()

### picon color
COLOREPLUGIN=resolveFilename(SCOPE_PLUGINS, "Extensions/TeamNitro/PICONS/")
config.plugins.TeamNitro = ConfigSubsection()
config.plugins.TeamNitro.piconpath = ConfigSelection(default = "PLUGIN", choices = [
    ("PLUGIN", _("PLUGIN")),
    ("MEDIA", _("MEDIA"))
    ])
config.plugins.TeamNitro.update = ConfigYesNo(default=True)

config.plugins.TeamNitro.MSNWeather = ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK"))
                                ])

config.plugins.TeamNitro.TNAbout = ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK"))
                                ])

config.plugins.TeamNitro.skin_selection = ConfigSelection(default="Press OK", choices = [
                                ("Press OK", _("Press OK"))
                                ])

REDC = '\033[31m'
ENDC = '\033[m'

def cprint(text):
    print(REDC + text + ENDC)

def removeunicode(data):
    try:
        try:
                data = data.encode('utf', 'ignore')
        except:
                pass
        data = data.decode('unicode_escape').encode('ascii', 'replace').replace('?', '').strip()
    except:
        pass
    return data

def trace_error():
    import sys
    import traceback
    try:
        traceback.print_exc(file=sys.stdout)
        traceback.print_exc(file=open('/tmp/TeamNitro.log', 'a'))
    except:
        pass

def getTeamNitroversioninfo():
    import os
    currversion = '0'
    version_file = '/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/version'
    if os.path.exists(version_file):
        try:
            fp = open(version_file, 'r').readlines()
            for line in fp:
                if 'versionNitro' in line:
                    currversion = line.split('=')[1].strip()
                elif 'versionDragon' in line:
                    currversion = line.split('=')[1].strip()
                elif 'versionBoHlala' in line:
                    currversion = line.split('=')[1].strip()
                elif 'versionDesert' in line:
                    currversion = line.split('=')[1].strip()
        except:
            pass
    return (currversion)

Ver = getTeamNitroversioninfo()  

def logdata(label_name = '', data = None):
    try:
        data=str(data)
        fp = open('/tmp/TeamNitro.log', 'a')
        fp.write( str(label_name) + ': ' + data+"\n")
        fp.close()
    except:
        trace_error()
        pass

def Plugins(**kwargs):
    return [PluginDescriptor(name=_("TeamNitro Config tool"), description=_("TeamNitro (Skins & Addons)"), where = [PluginDescriptor.WHERE_PLUGINMENU],
    icon="plugin.png", fnc=main)]

def main(session, **kwargs):
    if config.skin.primary_skin.value == "NitroAdvanceFHD/skin.xml":
        session.open(TeamNitro_Config)
    elif config.skin.primary_skin.value == "RED_DRAGON_FHD/skin.xml":
        session.open(TeamNitro_Config)
    elif config.skin.primary_skin.value == "BoHLALA_FHD/skin.xml":
        session.open(TeamNitro_Config)
    elif config.skin.primary_skin.value == "DesertFHD/skin.xml":
        session.open(TeamNitro_Config)
    else:
        AddPopup(_('Please activate TeamNitro Skin before run the Config Plugin'), type=MessageBox.TYPE_ERROR, timeout=10)
        return []

def isInteger(s):
    try:
        int(s)
        return True
    except ValueError:
        return False

def getmDevices():
        myusb = myusb1 = myhdd = myhdd2 = mysdcard = mysd = myuniverse = myba = mydata =''
        mdevices = []
        myusb=None
        myusb1=None
        myhdd=None
        myhdd2=None
        mysdcard=None
        mysd=None
        myuniverse=None
        myba=None
        mydata=None
        if fileExists('/proc/mounts'):
            f = open('/proc/mounts', 'r')
            for line in f.readlines():
                if line.find('/media/usb') != -1:
                    myusb = '/media/usb'
                elif line.find('/media/usb1') != -1:
                    myusb1 = '/media/usb1'
                elif line.find('/media/hdd') != -1:
                    myhdd = '/media/hdd'
                elif line.find('/media/hdd2') != -1:
                    myhdd2 = '/media/hdd2'
                elif line.find('/media/sdcard') != -1:
                    mysdcard = '/media/sdcard'
                elif line.find('/media/sd') != -1:
                    mysd = '/media/sd'
                elif line.find('/universe') != -1:
                    myuniverse = '/universe'
                elif line.find('/media/ba') != -1:
                    myba = '/media/ba'
                elif line.find('/data') != -1:
                    mydata = '/data'
            f.close()
        if myusb:
            mdevices.append((myusb, myusb))
        if myusb1:
            mdevices.append((myusb1, myusb1))
        if myhdd:
            mdevices.append((myhdd, myhdd))
        if myhdd2:
            mdevices.append((myhdd2, myhdd2))
        if mysdcard:
            mdevices.append((mysdcard, mysdcard))
        if mysd:
            mdevices.append((mysd, mysd))
        if myuniverse:
            mdevices.append((myuniverse, myuniverse))
        if myba:
            mdevices.append((myba, myba))
        if mydata:
            mdevices.append((mydata, mydata))
        return mdevices

mounted_devices = getmDevices()
config.plugins.TeamNitro.device_path = ConfigSelection(choices = mounted_devices)

if config.plugins.TeamNitro.piconpath.value == "PLUGIN":
	PATHPICON = '/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro'
else:
	PATHPICON = config.plugins.TeamNitro.device_path.value


class TeamNitro_Config(Screen, ConfigListScreen):

    skin = """
            <screen name="TeamNitro_Config" position="0,0" size="1920,1080" title="TN_Setup" flags="wfNoBorder" backgroundColor="transparent">
                <widget source="session.VideoPicture" render="Pig" position="1186,560" size="680,400" zPosition="3" backgroundColor="transparent2" />
                <ePixmap position="0,0" size="1920,1080" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/mn.png" alphatest="off" transparent="1" />
                <widget source="Title" render="Label" position="63,25" size="1790,68" zPosition="1" halign="center" font="Regular;46" backgroundColor="bglist" transparent="1" />
                <widget name="config" position="50,145" size="1065,810" font="Regular;34" itemHeight="45" enableWrapAround="1" transparent="1" />
                <widget name="Picture" position="1186,137" size="680,400" alphatest="blend" />
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/red48x48.png" position="65,1005" size="48,48" alphatest="blend" />
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/green48x48.png" position="542,1005" size="48,48" alphatest="blend" />
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/yellow48x48.png" position="1020,1005" size="48,48" alphatest="blend" />
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/blue48x48.png" position="1495,1005" size="48,48" alphatest="blend" />
                <widget name="key_red" position="113,1005" size="300,48" zPosition="1" font="Regular; 35" halign="left" valign="center" backgroundColor="#000000" transparent="1" foregroundColor="#FA0909" />
                <widget name="key_green" position="590,1005" size="300,48" zPosition="1" font="Regular; 35" halign="left" valign="center" backgroundColor="#000000" transparent="1" foregroundColor="#05A115" />
                <widget name="key_yellow" position="1068,1005" size="300,48" zPosition="1" font="Regular; 35" halign="left" valign="center" backgroundColor="#000000" transparent="1" foregroundColor="#FAFF00" />
                <widget name="key_blue" position="1545,1005" size="310,48" zPosition="1" font="Regular; 35" halign="left" valign="center" backgroundColor="#000000" transparent="1" foregroundColor="#0047FF" />
            </screen>
    """

    def __init__(self, session, args = 0):
        self.session = session
        self.changed_screens = False
        Screen.__init__(self, session)
        self.start_skin = config.skin.primary_skin.value
        if self.start_skin != "skin.xml":
            self.getInitConfig()
        self.list = []
        ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
        self.configChanged = False
        self["key_red"] = Label(_("Cancel"))
        self["key_green"] = Label(_("OK"))
        self["key_yellow"] = Label()
        self["key_blue"] = Label(_("Download Picons"))
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "EPGSelectActions"],
                {
                        "green": self.keyGreen,
                        "red": self.cancel,
                        "yellow": self.keyYellow,
                        "blue": self.picon,
                        "cancel": self.cancel,
                        "ok": self.keyOk,
                        "right": self.keyRight,
                        "left": self.keyLeft,
                }, -2)

        self["Picture"] = Pixmap()
        self.timer = eTimer()
        if config.plugins.TeamNitro.update.value:
            self.checkupdates()
            self.checkupdates2()
            self.checkupdates3()
            self.checkupdates4()
        if not self.selectionChanged in self["config"].onSelectionChanged:
            self["config"].onSelectionChanged.append(self.selectionChanged)
        self.createConfigList()
        if self.start_skin == "skin.xml":
            self.onLayoutFinish.append(self.openSkinSelectorDelayed)
        else:
            self.createConfigList()

    def getInitConfig(self):

        global cur_skin

        self.title = _("%s Setup" % cur_skin)
        self.skin_base_dir = "/usr/share/enigma2/%s/" % cur_skin
        cprint("self.skin_base_dir=%s, skin=%s, currentSkin=%s" % (self.skin_base_dir, config.skin.primary_skin.value, cur_skin))

        self.default_font_file = "font_Original.xml"
        self.default_color_file = "color_Original.xml"
        self.default_interface_file = "interface_Original.xml"
        self.default_posterX_file = "posterX_Original.xml"
        self.default_xtraEvent_file = "xtraEvent_Original.xml"
        self.default_xtraGenrepic_file = "xtraGenrepic_Original.xml"
        self.default_infobar_file = "infobar_Original.xml"
        self.default_channelselection_file = "channelselection_Original.xml"
        self.default_secondinfobar_file = "secondinfobar_Original.xml"

        self.color_file = "skin_user_color.xml"
        self.interface_file = "skin_user_interface.xml"
        self.posterX_file = "skin_user_posterX.xml"
        self.xtraEvent_file = "skin_user_xtraEvent.xml"
        self.xtraGenrepic_file = "skin_user_xtraGenrepic_Original.xml"
        self.infobar_file = "skin_user_infobar.xml"
        self.channelselection_file = "skin_user_channelselection.xml"
        self.secondinfobar_file = "skin_user_secondinfobar.xml"

        # color
        current, choices = self.getSettings(self.default_color_file, self.color_file)
        self.TeamNitro_color = NoSave(ConfigSelection(default=current, choices = choices))
        # interface
        current, choices = self.getSettings(self.default_interface_file, self.interface_file)
        self.TeamNitro_interface = NoSave(ConfigSelection(default=current, choices = choices))
        # posterX
        current, choices = self.getSettings(self.default_posterX_file, self.posterX_file)
        self.TeamNitro_posterX = NoSave(ConfigSelection(default=current, choices = choices))
        # xtraEvent
        current, choices = self.getSettings(self.default_xtraEvent_file, self.xtraEvent_file)
        self.TeamNitro_xtraEvent = NoSave(ConfigSelection(default=current, choices = choices))
        # xtraGenrepic
        current, choices = self.getSettings(self.default_xtraGenrepic_file, self.xtraGenrepic_file)
        self.TeamNitro_xtraGenrepic = NoSave(ConfigSelection(default=current, choices = choices))
        # infobar
        current, choices = self.getSettings(self.default_infobar_file, self.infobar_file)
        self.TeamNitro_infobar = NoSave(ConfigSelection(default=current, choices = choices))
        # secondinfobar
        current, choices = self.getSettings(self.default_secondinfobar_file, self.secondinfobar_file)
        self.TeamNitro_secondinfobar = NoSave(ConfigSelection(default=current, choices = choices))
        # channelselection
        current, choices = self.getSettings(self.default_channelselection_file, self.channelselection_file)
        self.TeamNitro_channelselection = NoSave(ConfigSelection(default=current, choices = choices))
        # myatile
        myatile_active = self.getmyAtileState()
        self.TeamNitro_active = NoSave(ConfigYesNo(default=False))
        self.TeamNitro_fake_entry = NoSave(ConfigNothing())

    def getSettings(self, default_file, user_file):
        # default setting
        default = ("default", _("Default"))

        # search typ
        styp = default_file.replace('_Original.xml', '')
        search_str = '%s_' % styp

        # possible setting
        choices = []
        files = listdir(self.skin_base_dir)
        if path.exists(self.skin_base_dir + 'allScreens/%s/' % styp):
            files += listdir(self.skin_base_dir + 'allScreens/%s/' % styp)
        for f in sorted(files, key=str.lower):
            if f.endswith('.xml') and f.startswith(search_str):
                friendly_name = f.replace(search_str, "").replace(".xml", "").replace("_", " ")
                if path.exists(self.skin_base_dir + 'allScreens/%s/%s' %(styp, f)):
                    choices.append((self.skin_base_dir + 'allScreens/%s/%s' %(styp, f), friendly_name))
                else:
                    choices.append((self.skin_base_dir + f, friendly_name))
        choices.append(default)

        # current setting
        myfile = self.skin_base_dir + user_file
        current = ''
        if not path.exists(myfile):
            if path.exists(self.skin_base_dir + default_file):
                if path.islink(myfile):
                    remove(myfile)
                chdir(self.skin_base_dir)
                symlink(default_file, user_file)
            elif path.exists(self.skin_base_dir + 'allScreens/%s/%s' % (styp, default_file)):
                if path.islink(myfile):
                    remove(myfile)
                chdir(self.skin_base_dir)
                symlink(self.skin_base_dir + 'allScreens/%s/%s' %(styp, default_file), user_file)
            else:
                current = None
        if current is None:
            current = default
        else:
            filename = path.realpath(myfile)
            friendly_name = path.basename(filename).replace(search_str, "").replace(".xml", "").replace("_", " ")
            current = (filename, friendly_name)

        return current[0], choices
        if path.exists(self.skin_base_dir + "mySkin_off"):
            if not path.exists(self.skin_base_dir + "TeamNitro_Selections"):
                chdir(self.skin_base_dir)
                try:
                    rename("mySkin_off", "TeamNitro_Selections")
                except:
                    pass

    def createConfigList(self):
        self.set_color = getConfigListEntry(_("Color:"), self.TeamNitro_color)

        self.set_interface = getConfigListEntry(_("Interface:"), self.TeamNitro_interface)

        self.set_posterX = getConfigListEntry(_("posterX:"), self.TeamNitro_posterX)

        self.set_xtraEvent = getConfigListEntry(_("xtraEvent:"), self.TeamNitro_xtraEvent)

        self.set_xtraGenrepic = getConfigListEntry(_("xtraGenrepic:"), self.TeamNitro_xtraGenrepic)

        self.set_infobar = getConfigListEntry(_("Infobar:"), self.TeamNitro_infobar)

        self.set_secondinfobar = getConfigListEntry(_("SecondInfobar:"), self.TeamNitro_secondinfobar)

        self.set_channelselection = getConfigListEntry(_("ChannelSelection:"), self.TeamNitro_channelselection)

        self.set_myatile = getConfigListEntry(_("Enable %s pro:") % cur_skin, self.TeamNitro_active)

        self.set_new_skin = getConfigListEntry(_("Change skin:"), config.plugins.TeamNitro.skin_selection)

        self.set_piconpath = getConfigListEntry(_("Select Path Of Picons Folder"), config.plugins.TeamNitro.piconpath)

        self.set_mounted_devices = getConfigListEntry(_("Select mount device"), config.plugins.TeamNitro.device_path)

        self.set_MSNWeather= getConfigListEntry(_("WeatherMSN_Settings:"), config.plugins.TeamNitro.MSNWeather)

        self.update = getConfigListEntry(_("Enable/Disable online update"), config.plugins.TeamNitro.update)

        self.set_TNAbout= getConfigListEntry(_("About TeamNitro:"), config.plugins.TeamNitro.TNAbout)

        self.LackOfFile = ''

        self.list = []

        self.list.append(self.set_myatile)
        self.list.append(self.set_MSNWeather)


        if self.TeamNitro_active.value == True:
            self["key_yellow"].setText("%s pro" % cur_skin)
            if len(self.TeamNitro_color.choices)>1:
                self.list.append(self.set_color)

            if len(self.TeamNitro_interface.choices)>1:
                self.list.append(self.set_interface)

            if len(self.TeamNitro_posterX.choices)>1:
                self.list.append(self.set_posterX)

            if len(self.TeamNitro_xtraEvent.choices)>1:
                self.list.append(self.set_xtraEvent)

            if len(self.TeamNitro_xtraGenrepic.choices)>1:
                self.list.append(self.set_xtraGenrepic)

            if len(self.TeamNitro_infobar.choices)>1:
                self.list.append(self.set_infobar)

            if len(self.TeamNitro_secondinfobar.choices)>1:
                self.list.append(self.set_secondinfobar)

            if len(self.TeamNitro_channelselection.choices)>1:
                self.list.append(self.set_channelselection)
        else:
            self["key_yellow"].setText("")
        self.list.append(self.set_new_skin)
        self.list.append(self.set_piconpath)
        if config.plugins.TeamNitro.piconpath.value == 'MEDIA':
            self.list.append(self.set_mounted_devices)
        self.list.append(self.update)
        self.list.append(self.set_TNAbout)
        self["config"].list = self.list
        self["config"].l.setList(self.list)

    def changedEntry(self):
        self.configChanged = True 
        if self["config"].getCurrent() == self.set_color:
            self.setPicture(self.TeamNitro_color.value)


        elif self["config"].getCurrent() == self.set_interface:
            self.setPicture(self.TeamNitro_interface.value)

        elif self["config"].getCurrent() == self.set_posterX:
            self.setPicture(self.TeamNitro_posterX.value)

        elif self["config"].getCurrent() == self.set_xtraEvent:
            self.setPicture(self.TeamNitro_xtraEvent.value)

        elif self["config"].getCurrent() == self.set_xtraGenrepic:
            self.setPicture(self.TeamNitro_xtraGenrepic.value)

        elif self["config"].getCurrent() == self.set_infobar:
            self.setPicture(self.TeamNitro_infobar.value)

        elif self["config"].getCurrent() == self.set_secondinfobar:
            self.setPicture(self.TeamNitro_secondinfobar.value)

        elif self["config"].getCurrent() == self.set_channelselection:
            self.setPicture(self.TeamNitro_channelselection.value)

        elif self["config"].getCurrent() == self.set_myatile:
            if self.TeamNitro_active.value == True:
                self["key_yellow"].setText("%s pro" % cur_skin)
            else:
                self["key_yellow"].setText("")
            self.createConfigList()

    def selectionChanged(self):
        if self["config"].getCurrent() == self.set_color:
            self.setPicture(self.TeamNitro_color.value)

        elif self["config"].getCurrent() == self.set_interface:
            self.setPicture(self.TeamNitro_interface.value)

        elif self["config"].getCurrent() == self.set_posterX:
            self.setPicture(self.TeamNitro_posterX.value)

        elif self["config"].getCurrent() == self.set_xtraEvent:
            self.setPicture(self.TeamNitro_xtraEvent.value)

        elif self["config"].getCurrent() == self.set_xtraGenrepic:
            self.setPicture(self.TeamNitro_xtraGenrepic.value)

        elif self["config"].getCurrent() == self.set_infobar:
            self.setPicture(self.TeamNitro_infobar.value)

        elif self["config"].getCurrent() == self.set_secondinfobar:
            self.setPicture(self.TeamNitro_secondinfobar.value)

        elif self["config"].getCurrent() == self.set_channelselection:
            self.setPicture(self.TeamNitro_channelselection.value)
        else:
            self["Picture"].hide()

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.createConfigList()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.createConfigList()

    def cancel(self):
        if self["config"].isChanged():
            self.session.openWithCallback(self.cancelConfirm, MessageBox, _("You want close without saving settings?"), MessageBox.TYPE_YESNO, default = False)
        else:
            for x in self["config"].list:
                x[1].cancel()
            if self.changed_screens:
                self.restartGUI()
            else:
                self.close()

    def cancelConfirm(self, result):
        if result == None or result == False:
            print("[%s]: Cancel confirmed." % cur_skin)
        else:
            print("[%s]: Cancel confirmed. Config changes will be lost." % cur_skin)
            for x in self["config"].list:
                x[1].cancel()
            self.close()

    def getmyAtileState(self):
        chdir(self.skin_base_dir)
        if path.exists("mySkin"):
            return True
        else:
            return False

    def setPicture(self, f):
        pic = f.split('/')[-1].replace(".xml", ".png")
        preview = self.skin_base_dir + "preview/preview_" + pic
        if path.exists(preview):
            self["Picture"].instance.setPixmapFromFile(preview)
            self["Picture"].show()
        else:
            self["Picture"].hide()

    def keyYellow(self):
        if self.TeamNitro_active.value:
            self.session.openWithCallback(self.TeamNitroScreenCB, TeamNitroScreens)
        else:
            self["config"].setCurrentIndex(0)

    def keyOk(self):
        sel =  self["config"].getCurrent()
        if sel != None and sel == self.set_new_skin:
            self.openSkinSelector()
        elif sel != None and sel == self.set_MSNWeather:
            self.session.open(WeatherMSN)
        elif sel != None and sel == self.set_TNAbout:
            self.session.open(TeamNitro_About)
        else:
            self.keyGreen()

    def openSkinSelector(self):
        self.session.openWithCallback(self.skinChanged, SkinSelector)

    def openSkinSelectorDelayed(self):
        self.delaytimer = eTimer()
        self.delaytimer.callback.append(self.openSkinSelector)
        self.delaytimer.start(200, True)

    def skinChanged(self, ret = None):
        global cur_skin
        cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
        if cur_skin == "skin.xml":
            self.restartGUI()
        else:
            self.getInitConfig()
            self.createConfigList()

    def keyGreen(self):
        if self["config"].isChanged():
            for x in self["config"].list:
                x[1].save()
            chdir(self.skin_base_dir)

            self.makeSettings(self.TeamNitro_color, self.color_file)

            self.makeSettings(self.TeamNitro_interface, self.interface_file)

            self.makeSettings(self.TeamNitro_posterX, self.posterX_file)

            self.makeSettings(self.TeamNitro_xtraEvent, self.xtraEvent_file)

            self.makeSettings(self.TeamNitro_xtraGenrepic, self.xtraGenrepic_file)

            self.makeSettings(self.TeamNitro_infobar, self.infobar_file)

            self.makeSettings(self.TeamNitro_secondinfobar, self.secondinfobar_file)

            self.makeSettings(self.TeamNitro_channelselection, self.channelselection_file)
            if not path.exists("mySkin_off"):
                mkdir("mySkin_off")
                print("makedir mySkin_off")
            if self.TeamNitro_active.value:
                if not path.exists("mySkin") and path.exists("mySkin_off"):
                    symlink("mySkin_off", "mySkin")
            else:
                if path.exists("mySkin"):
                    if path.exists("mySkin_off"):
                        if path.islink("mySkin"):
                            remove("mySkin")
                        else:
                            shutil.rmtree("mySkin")
                    else:
                        rename("mySkin", "mySkin_off")
            self.update_user_skin()
            self.restartGUI()
        elif  config.skin.primary_skin.value != self.start_skin:
            self.update_user_skin()
            self.restartGUI()
        else:
            if self.changed_screens:
                self.update_user_skin()
                self.restartGUI()
            else:
                self.close()

    def makeSettings(self, config_entry, user_file):
        if path.exists(user_file):
            remove(user_file)
        if path.islink(user_file):
            remove(user_file)
        if config_entry.value != 'default':
            symlink(config_entry.value, user_file)

    def TeamNitroScreenCB(self):
        self.changed_screens = True
        self["config"].setCurrentIndex(0)

    def restartGUI(self):
        myMessage = ''
        if self.LackOfFile != '':
            cprint("missing components: %s" % self.LackOfFile)
            myMessage += _("Missing components found: %s\n\n") % self.LackOfFile
            myMessage += _("Skin will NOT work properly!!!\n\n")
        restartbox = self.session.openWithCallback(self.restartGUIcb, MessageBox, _("Restart necessary, restart GUI now?"), MessageBox.TYPE_YESNO)
        restartbox.setTitle(_("Message"))

    def picon(self):
        self.session.open(PiconsScreen)

    def restartGUIcb(self, answer):
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()

    def update_user_skin(self):
        global cur_skin
        user_skin_file = resolveFilename(SCOPE_CONFIG, 'skin_user_' + cur_skin + '.xml')
        if path.exists(user_skin_file):
            remove(user_skin_file)
        cprint("update_user_skin.self.TeamNitro_active.value")
        user_skin = ""
        if path.exists(self.skin_base_dir + self.color_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.color_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + self.interface_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.interface_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + self.posterX_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.posterX_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + self.xtraEvent_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.xtraEvent_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + self.xtraGenrepic_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.xtraGenrepic_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + self.infobar_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.infobar_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + self.secondinfobar_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.secondinfobar_file, 'ALLSECTIONS')
        if path.exists(self.skin_base_dir + self.channelselection_file):
            user_skin = user_skin + self.readXMLfile(self.skin_base_dir + self.channelselection_file, 'ALLSECTIONS')

        if path.exists(self.skin_base_dir + 'mySkin'):
            for f in listdir(self.skin_base_dir + "mySkin/"):
                user_skin = user_skin + self.readXMLfile(self.skin_base_dir + "mySkin/" + f, 'screen')
        if user_skin != '':
            user_skin = "<skin>\n" + user_skin
            user_skin = user_skin + "</skin>\n"
            with open(user_skin_file, "w") as myFile:
                cprint("update_user_skin.self.TeamNitro_active.value write myFile")
                myFile.write(user_skin)
                myFile.flush()
                myFile.close()
        self.checkComponent(user_skin, 'render', resolveFilename(SCOPE_PLUGINS, '../Components/Renderer/') )
        self.checkComponent(user_skin, 'Convert', resolveFilename(SCOPE_PLUGINS, '../Components/Converter/') )
        self.checkComponent(user_skin, 'pixmap', resolveFilename(SCOPE_SKIN, '') )
               
    def checkComponent(self, myContent, look4Component, myPath):
        def updateLackOfFile(name, mySeparator =', '):
                cprint("Missing component found:%s\n" % name)
                if self.LackOfFile == '':
                        self.LackOfFile = name
                else:
                        self.LackOfFile += mySeparator + name
            
        r=re.findall( r' %s="([a-zA-Z0-9_/\.]+)" ' % look4Component, myContent )
        r=list(set(r))

        cprint("Found %s:\n" % (look4Component))
        print(r)
        if r:
                for myComponent in set(r):
                        if look4Component == 'pixmap':
                                if myComponent.startswith('/'):
                                        if not path.exists(myComponent):
                                                updateLackOfFile(myComponent, '\n')
                                else:
                                        if not path.exists(myPath + myComponent):
                                                updateLackOfFile(myComponent)
                        else:
                                if not path.exists(myPath + myComponent + ".pyo") and not path.exists(myPath + myComponent + ".py") and not path.exists(myPath + myComponent + ".pyc"):
                                        updateLackOfFile(myComponent)
        return
    
    def readXMLfile(self, XMLfilename, XMLsection):
        myPath=path.realpath(XMLfilename)
        if not path.exists(myPath):
                remove(XMLfilename)
                return ''
        filecontent = ''
        if XMLsection == 'ALLSECTIONS':
                sectionmarker = True
        else:
                sectionmarker = False
        with open (XMLfilename, "r") as myFile:
                for line in myFile:
                        if line.find('<skin>') >= 0 or line.find('</skin>') >= 0:
                                continue
                        if line.find('<%s' %XMLsection) >= 0 and sectionmarker == False:
                                sectionmarker = True
                        elif line.find('</%s>' %XMLsection) >= 0 and sectionmarker == True:
                                sectionmarker = False
                                filecontent = filecontent + line
                        if sectionmarker == True:
                                filecontent = filecontent + line
                myFile.close()
        return filecontent

    def checkupdates(self):
        url = 'https://raw.githubusercontent.com/biko-73/TeamNitro/main/installerDragon.sh'
        self.callUrl(url, self.checkVer)

    def checkupdates2(self):
        url2 = 'https://raw.githubusercontent.com/biko-73/TeamNitro/main/installerNitro.sh'
        self.callUrl(url2, self.checkVer)

    def checkupdates3(self):
        url3 = 'https://raw.githubusercontent.com/biko-73/TeamNitro/main/installerBoHlala.sh'
        self.callUrl(url3, self.checkVer)

    def checkupdates4(self):
        url4 = 'https://raw.githubusercontent.com/biko-73/TeamNitro/main/installerDesert.sh'
        self.callUrl(url4, self.checkVer)

    def checkVer(self, data):
        if PY3:
            data = data.decode("utf-8")
        else:
            data = data.encode("utf-8")
        if data:
            lines = data.split("\n")
            for line in lines:
                if line.startswith("version"):
                   self.new_version = line.split("=")[1]
                if line.startswith("version"):
                   self.new_version = line.split("=")[1]
                if line.startswith("description"):
                   self.new_description = line.split("=")[1]
                   break
        if float(Ver) == float(self.new_version) or float(Ver) > float(self.new_version):
            pass
        else:
            new_version = self.new_version
            new_description = self.new_description
            self.session.openWithCallback(self.installupdate, MessageBox, _('New version %s is available.\n\n%s.\n\nDo you want to install it now.' % (self.new_version, self.new_description)), MessageBox.TYPE_YESNO)

    def installupdate(self, answer=False):
        if answer:
            cmdlist = []
            cmdlist.append('wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/TeamNitro/main/installerDragon.sh -O - | /bin/sh')
            self.session.open(Console2, title='Update TeamNitro Skin', cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)
        elif answer:
            cmdlist = []
            cmdlist.append('wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/TeamNitro/main/installerNitro.sh -O - | /bin/sh')
            self.session.open(Console2, title='Update TeamNitro Skin', cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)
        elif answer:
            cmdlist = []
            cmdlist.append('wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/TeamNitro/main/installerBoHlala.sh -O - | /bin/sh')
            self.session.open(Console2, title='Update TeamNitro Skin', cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)
        elif answer:
            cmdlist = []
            cmdlist.append('wget -q "--no-check-certificate" https://raw.githubusercontent.com/biko-73/TeamNitro/main/installerDesert.sh -O - | /bin/sh')
            self.session.open(Console2, title='Update TeamNitro Skin', cmdlist=cmdlist, finishedCallback=self.myCallback, closeOnSuccess=False)

    def myCallback(self, result=None):
        return

    def callUrl(self, url, callback):
        try:
            from twisted.web.client import getPage
            getPage(str.encode(url), headers={b'Content-Type': b'application/x-www-form-urlencoded'}).addCallback(callback).addErrback(self.addErrback)
        except:
            pass

    def addErrback(self, error=None):
        pass        

class TeamNitroScreens(Screen):
        if reswidth == 1920:
                skin = """
                        <screen name="TeamNitroScreens" backgroundColor="transparent" flags="wfNoBorder" position="0,0" size="1920,1080" title="TN_Setup">
                            <widget source="session.VideoPicture" render="Pig" position="1186,560" size="680,400" zPosition="3" backgroundColor="transparent2" />
                            <ePixmap position="0,0" size="1920,1080" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/mn.jpg" alphatest="off" transparent="1" />
                            <widget source="Title" render="Label" position="63,25" size="1790,68" zPosition="1" halign="center" font="Regular;46" backgroundColor="bglist" transparent="1" />
                            <widget source="menu" render="Listbox" position="50,140" size="1065,820" scrollbarMode="showNever" scrollbarWidth="9" enableWrapAround="1" transparent="1">
                                <convert type="TemplatedMultiContent">
                                {"template":
                                    [
                                    MultiContentEntryPixmapAlphaTest(pos = (15, 13), size = (40, 40), png = 2),
                                    MultiContentEntryText(pos = (70, 0), size = (1050, 50), font=0, flags = RT_HALIGN_LEFT|RT_VALIGN_CENTER, text = 1),
                                    ],
                                    "fonts": [gFont("Regular", 40),gFont("Regular", 32)],
                                    "itemHeight": 45
                                }
                                </convert>
                            </widget>
                            <widget name="Picture" position="1186,137" size="680,400" alphatest="blend" />
                            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/red48x48.png" position="65,1005" size="48,48" alphatest="blend" />
                            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/green48x48.png" position="542,1005" size="48,48" alphatest="blend" />
                            <widget name="key_red" position="113,1005" size="300,48" zPosition="1" font="Regular; 35" halign="left" valign="center" backgroundColor="#000000" transparent="1" foregroundColor="#FA0909" />
                            <widget name="key_green" position="590,1005" size="300,48" zPosition="1" font="Regular; 35" halign="left" valign="center" backgroundColor="#000000" transparent="1" foregroundColor="#05A115" />
                        </screen>
                """
        def __init__(self, session):
                Screen.__init__(self, session)
                self.session = session
                
                global cur_skin
                
                self.title = _("%s additional screens") % cur_skin
                try:
                        self["title"]=StaticText(self.title)
                except:
                        cprint("self['title'] was not found in skin")
                
                self["key_red"] = StaticText(_("Exit"))
                self["key_green"] = StaticText(_("on"))
                
                self["Picture"] = Pixmap()
                
                menu_list = []
                self["menu"] = List(menu_list)
                
                self["shortcuts"] = ActionMap(["SetupActions", "ColorActions", "DirectionActions"],
                {
                        "ok": self.runMenuEntry,
                        "cancel": self.keyCancel,
                        "red": self.keyCancel,
                        "green": self.runMenuEntry,
                }, -2)
                
                self.skin_base_dir = "/usr/share/enigma2/%s/" % cur_skin
                self.screen_dir = "allScreens"
                self.skinparts_dir = "skinparts"
                self.file_dir = "mySkin_off"
                my_path = resolveFilename(SCOPE_SKIN, "%s/icons/lock_on.png" % cur_skin)
                if not path.exists(my_path):
                        my_path = resolveFilename(SCOPE_PLUGINS, "Extensions/TeamNitro/pic/lock_on.png")
                self.enabled_pic = LoadPixmap(cached = True, path = my_path)
                my_path = resolveFilename(SCOPE_SKIN, "%s/icons/lock_off.png" % cur_skin)
                if not path.exists(my_path):
                        my_path = resolveFilename(SCOPE_PLUGINS, "Extensions/TeamNitro/pic/lock_off.png")
                self.disabled_pic = LoadPixmap(cached = True, path = my_path)
                if not self.selectionChanged in self["menu"].onSelectionChanged:
                        self["menu"].onSelectionChanged.append(self.selectionChanged)
                self.onLayoutFinish.append(self.createMenuList)

        def selectionChanged(self):
                sel = self["menu"].getCurrent()
                if sel != None:
                        self.setPicture(sel[0])
                        if sel[2] == self.enabled_pic:
                                self["key_green"].setText(_("off"))
                        elif sel[2] == self.disabled_pic:
                                self["key_green"].setText(_("on"))

        def createMenuList(self):
                chdir(self.skin_base_dir)
                f_list = []
                dir_path = self.skin_base_dir + self.screen_dir
                if not path.exists(dir_path):
                        makedirs(dir_path)
                dir_skinparts_path = self.skin_base_dir + self.skinparts_dir
                if not path.exists(dir_skinparts_path):
                        makedirs(dir_skinparts_path)
                file_dir_path = self.skin_base_dir + self.file_dir
                if not path.exists(file_dir_path):
                        makedirs(file_dir_path)
                dir_global_skinparts = resolveFilename(SCOPE_SKIN, "skinparts")
                if path.exists(dir_global_skinparts):
                        for pack in listdir(dir_global_skinparts):
                                if path.isdir(dir_global_skinparts + "/" + pack):
                                        for f in listdir(dir_global_skinparts + "/" + pack):
                                                if path.exists(dir_global_skinparts + "/" + pack + "/" + f + "/" + f + "_Atile.xml"):
                                                        if not path.exists(dir_path + "/skin_" + f + ".xml"):
                                                                symlink(dir_global_skinparts + "/" + pack + "/" + f + "/" + f + "_Atile.xml", dir_path + "/skin_" + f + ".xml")
                                                        if not path.exists(dir_skinparts_path + "/" + f):
                                                                symlink(dir_global_skinparts + "/" + pack + "/" + f, dir_skinparts_path + "/" + f)
                list_dir = sorted(listdir(dir_path), key=str.lower)
                for f in list_dir:
                        if f.endswith('.xml') and f.startswith('skin_'):
                                if (not path.islink(dir_path + "/" + f)) or os.path.exists(os.readlink(dir_path + "/" + f)):
                                        friendly_name = f.replace("skin_", "")
                                        friendly_name = friendly_name.replace(".xml", "")
                                        friendly_name = friendly_name.replace("_", " ")
                                        linked_file = file_dir_path + "/" + f
                                        if path.exists(linked_file):
                                                if path.islink(linked_file):
                                                        pic = self.enabled_pic
                                                else:
                                                        remove(linked_file)
                                                        symlink(dir_path + "/" + f, file_dir_path + "/" + f)
                                                        pic = self.enabled_pic
                                        else:
                                                pic = self.disabled_pic
                                        f_list.append((f, friendly_name, pic))
                                else:
                                        if path.islink(dir_path + "/" + f):
                                                remove(dir_path + "/" + f)
                menu_list = [ ]
                for entry in f_list:
                        menu_list.append((entry[0], entry[1], entry[2]))
                self["menu"].updateList(menu_list)
                self.selectionChanged()

        def setPicture(self, f):
                pic = f.replace(".xml", ".png")
                preview = self.skin_base_dir + "allPreviews/preview_" + pic
                if path.exists(preview):
                        self["Picture"].instance.setPixmapFromFile(preview)
                        self["Picture"].show()
                else:
                        self["Picture"].hide()
        
        def keyCancel(self):
                self.close()

        def runMenuEntry(self):
                sel = self["menu"].getCurrent()
                if sel != None:
                        if sel[2] == self.enabled_pic:
                                remove(self.skin_base_dir + self.file_dir + "/" + sel[0])
                        elif sel[2] == self.disabled_pic:
                                symlink(self.skin_base_dir + self.screen_dir + "/" + sel[0], self.skin_base_dir + self.file_dir + "/" + sel[0])
                        self.createMenuList()

class PiconsScreen(Screen):
        skin = """
            <screen name="PiconsScreen" position="0,0" size="1920,1080" title="TN_Icons Download" backgroundColor="transparent">
                <ePixmap position="0,0" size="1920,1080" zPosition="-2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/mn.png" alphatest="off" transparent="1" />
                <widget source="session.VideoPicture" render="Pig" position="1186,560" size="680,400" zPosition="3" backgroundColor="transparent2" />
                <widget name="Picture" position="1186,137" size="680,400" alphatest="blend" />
                <widget source="Title" render="Label" position="63,25" size="1790,68" zPosition="1" halign="center" font="Regular;46" backgroundColor="bglist" transparent="1" />
                <widget name="menu" position="50,140" size="1065,675" font="Regular; 35" itemHeight="45" scrollbarMode="showNever" transparent="1" zPosition="1" />
                <eLabel text="Select and Press OK to Downlaod Picons" position="50,823" size="1065,40" font="Regular; 32" foregroundColor="#ff2525" backgroundColor="#16000000" valign="center" halign="center" transparent="1" zPosition="5" />
                <eLabel text="The Picons will be find inside plugin in (PICONS) Folder" position="50,867" size="1065,90" font="Regular; 38" foregroundColor="#bab329" backgroundColor="#16000000" valign="center" halign="center" transparent="1" zPosition="5" />
            </screen>
            """
        def __init__(self, session, args = 0):
                self.session = session
                self.changed_screens = False
                Screen.__init__(self, session)
                self.TeamNitro_fake_entry = NoSave(ConfigNothing())

                self["setupActions"] = ActionMap(["SetupActions"],
                {
                        "cancel": self.cancel,
                        "ok": self.DownloadPicons
                }, -1)

                self["Picture"] = Pixmap()

                list = []
                list.append((_("Black Picons"), "Black"))
                list.append((_("White Picons"), "White"))
                list.append((_("Transparent Picons"), "Transparent"))
                list.append((_("zelda Picon"), "zeldaPicon"))
                self["menu"] = MenuList(list)
                self["menu"].onSelectionChanged.append(self.Picture)
                self.onShow.append(self.Picture)
                self.onLayoutFinish.append(self.setWindowTitle)

        def setWindowTitle(self):
                self.setTitle(_("Nitro Satellite Provider Picons Download"))

        def Picture(self):
                try:
                        index = self["menu"].l.getCurrentSelection()[1]
                        if index == "Black":
                                pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/BlackPicon.png')
                        elif index == "White":
                                pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/WhitePicon.png')
                        elif index == "Transparent":
                                pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/TransparentPicon.png')
                        elif index == "zeldaPicon":
                                pic = resolveFilename(SCOPE_PLUGINS, 'Extensions/TeamNitro/images/preview/zeldaPicon.png')
                        self['Picture'].instance.setPixmapFromFile(pic)
                except Exception as error:
                        logdata("Picture preview:", error)

        def DownloadPicons(self):
                self.session.openWithCallback(self.installPicon, MessageBox, _('Do want to Download it now ?!!'), MessageBox.TYPE_YESNO)

        def installPicon(self, answer=False):
                try:
                        if answer:
                                cmdlist = []
                                index = self["menu"].l.getCurrentSelection()[1]
                                PICONTMP='/tmp/PICONS'
                                if index == "Black":
                                        os.system("wget -O '/tmp/BlackPicons.tar.gz' 'https://github.com/biko-73/TeamNitro/raw/main/BlackPicons.tar.gz'")
                                        os.system("tar -xzf /tmp/BlackPicons.tar.gz -C /")
                                elif index == "White":
                                        os.system("wget -O '/tmp/WhitePicons.tar.gz' 'https://github.com/biko-73/TeamNitro/raw/main/WhitePicons.tar.gz'")
                                        os.system("tar -xzf /tmp/WhitePicons.tar.gz -C /")
                                elif index == "Transparent":
                                        os.system("wget -O '/tmp/TransparentPicons.tar.gz' 'https://github.com/biko-73/TeamNitro/raw/main/TransparentPicons.tar.gz'")
                                        os.system("tar -xzf /tmp/TransparentPicons.tar.gz -C /")
                                elif index == "Transparent":
                                        os.system("wget -O '/tmp/zeldaPicon.tar.gz' 'https://github.com/biko-73/TeamNitro/raw/main/zeldaPicon.tar.gz'")
                                        os.system("tar -xzf /tmp/zeldaPicon.tar.gz -C /")
                                if pathExists(PATHPICON + '/PICONS'):
                                    shutil.rmtree(PATHPICON + '/PICONS')
                                shutil.move(PICONTMP, PATHPICON)
                                os.system("rm -rf /tmp/*Picons*")
                                os.system("rm -rf /tmp/*PICONS*")
                                self.session.open(Console, title='Download and Installing Picons', cmdlist=cmdlist, finishedCallback=self.Finished, closeOnSuccess=True)
                        else:
                                self.close()
                except:
                    trace_error()

        def Finished(self):
                self.session.open(MessageBox, _('Download and Installing Finished'), MessageBox.TYPE_INFO,timeout=4)

        def cancel(self):
                self.close()
