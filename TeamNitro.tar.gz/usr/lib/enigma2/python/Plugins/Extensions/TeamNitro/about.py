#!/usr/bin/python
# -*- coding: utf-8 -*-

# for localized messages
from . import _

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from Screens.Screen import Screen


class TeamNitro_About(Screen):
    skin = """
    <screen name="TN_About" position="0,0" size="1920,1080" backgroundColor="#232323" flags="wfNoBorder">
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/images/mn.png" position="0,0" size="1920,1080" alphatest="blend" />
        <widget source="session.VideoPicture" render="Pig" position="1187,606" size="671,393" zPosition="3" backgroundColor="transparent" />
        <widget name="about" position="262,167" size="806,757" font="Regular;35" foregroundColor="#ffffff" backgroundColor="#232323" transparent="1" zPosition="2" />
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TeamNitro/pic/red48x48.png" position="488,960" size="48,48" alphatest="blend" />
        <widget source="key_red" render="Label" position="560,960" size="300,48" zPosition="1" font="Regular; 35" halign="left" valign="center" backgroundColor="#000000" transparent="1" foregroundColor="#FA0909" />
    </screen>
    """
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self.setup_title = _('About TeamNitro')

        self['actions'] = ActionMap(['SetupActions'], {
            'ok': self.quit,
            'cancel': self.quit,
            'menu': self.quit}, -2)
        self['key_red'] = StaticText(_('Close'))
        self['about'] = Label('')
        self.onFirstExecBegin.append(self.createSetup)
        self.onLayoutFinish.append(self.__layoutFinished)

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def createSetup(self):
        self.credit = '*****************************************************************\n'
        self.credit +=  '*** TeamNitro Plugin Developed by - KIMOO and Bahaa ****\n\n'
        self.credit += '****************************************************************\n\n\n'
        self.credit += 'When Designing the first version of Nitro Skin\n'
        self.credit += 'the need increased fot two plugins that could show the\n'
        self.credit += 'additional screen of the skin\n'
        self.credit += 'as these properties were not available on the images by default\n'
        self.credit += 'except for the image openatv – opendroid\n\n\n\n'
        self['about'].setText(self.credit)

    def quit(self):
        self.close()




